package com.tenanttrust.model.dto;

import com.tenanttrust.model.entities.User;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AuthResponseDTO
{
    private String token;
    private User user;
    private boolean success;
    private String message;
    private LocalDateTime timestamp;

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public User getUser()
    {
        return user;
    }

    public void setUser(User user)
    {
        this.user = user;
    }

    public AuthResponseDTO(boolean success, String message, String token, User user)
    {
        this.success = success;
        this.message = message;
        this.token = token;
        this.user = user;
        this.timestamp = LocalDateTime.now();
    }


    // Full constructor
    public AuthResponseDTO(String token, User user)
    {
        this.token = token;
        this.user = user;
    }

    // Constructor without user (for errors)
    public AuthResponseDTO(boolean success, String message)
    {
        this.success = success;
        this.message = message;
        this.token = null;
        this.user = null;
        this.timestamp = LocalDateTime.now();
    }

    // ✅ THIS IS THE METHOD YOU NEEDED
    public static AuthResponseDTO error(String message)
    {
        return new AuthResponseDTO(false, message, null, null);
    }

    // Success method with token and user
    public static AuthResponseDTO success(String message, String token, User user)
    {
        return new AuthResponseDTO(true, message, token, user);
    }

    // Success method without user (for simple operations)
    public static AuthResponseDTO success(String message)
    {
        return new AuthResponseDTO(true, message, null, null);
    }

    // Success method with token only
    public static AuthResponseDTO success(String message, String token)
    {
        return new AuthResponseDTO(true, message, token, null);
    }

    // Getter for success - required for response.isSuccess()
    public boolean isSuccess()
    {
        return success;
    }

    // Additional helper methods
    public boolean hasToken()
    {
        return token != null && !token.trim().isEmpty();
    }

    public boolean hasUser()
    {
        return user != null;
    }

    // Builder pattern for fluent API (optional)
    public static Builder builder()
    {
        return new Builder();
    }

    // Builder class
    public static class Builder
    {
        private boolean success;
        private String message;
        private String token;
        private User user;

        public Builder success(boolean success)
        {
            this.success = success;
            return (Builder) this;
        }

        public Builder message(String message)
        {
            this.message = message;
            return (Builder) this;
        }

        public Builder token(String token)
        {
            this.token = token;
            return (Builder) this;
        }

        public Builder user(User user)
        {
            this.user = user;
            return (Builder) this;
        }

        public AuthResponseDTO build()
        {
            return new AuthResponseDTO(success, message, token, user);
        }
    }

    // ✅ THIS IS WHERE fromUser() METHOD SHOULD BE
    public static User fromUser(User user)
    {
        if (user == null)
        {
            return null;
        }

        User dto = new User();
        dto.setId(user.getId());
        dto.setEmail(user.getEmail());
        dto.setFullName(user.getFullName());
        dto.setRole(user.getRole());
        dto.setProvider(user.getProvider());
        dto.setCreatedAt(user.getCreatedAt());
//        dto.setLastLogin(user.getLastLogin());

        return dto;
    }
}

