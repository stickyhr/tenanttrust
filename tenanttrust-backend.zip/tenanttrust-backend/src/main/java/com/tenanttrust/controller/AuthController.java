package com.tenanttrust.controller;

import com.tenanttrust.config.JwtService;
import com.tenanttrust.model.dto.AuthRequestDTO;
import com.tenanttrust.model.dto.AuthResponseDTO;
import com.tenanttrust.model.entities.User;
import com.tenanttrust.repository.UserRepository;
import com.tenanttrust.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController
{
    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final JwtService jwtService;
    private final PasswordEncoder passwordEncoder;

    private final UserService userService;

    // Manual constructor injection
    @Autowired
    public AuthController(UserRepository userRepository, JwtService jwtService, PasswordEncoder passwordEncoder, AuthenticationManager authenticationManager, UserService userService)
    {
        this.userRepository = userRepository;
        this.jwtService = jwtService;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.userService = userService;
    }

//    @PostMapping("/register") // old working endpoint
//    public ResponseEntity<AuthResponseDTO> register(@Valid @RequestBody AuthRequestDTO authRequestDTO)
//    {
//        if (userRepository.existsByEmail(authRequestDTO.getEmail()))
//        {
//            throw new RuntimeException("Email already exists");
//        }
//
//        User user = new User();
//        user.setEmail(authRequestDTO.getEmail());
//        user.setPassword(passwordEncoder.encode(authRequestDTO.getPassword()));
////        user.setFullName(authRequestDTO.getEmail().split("@")[0]); // Default name
//        user.setFullName(authRequestDTO.getFullName()); // taking full name from request
//        user.setRole(User.UserRole.TENANT); // Default role as TENANT for now
//
//        User savedUser = userRepository.save(user);
//        String jwt = jwtService.generateToken(savedUser);
//
//        return ResponseEntity.ok(new AuthResponseDTO(jwt, savedUser));
//    }

    @PostMapping("/register") // we are going with the old working endpoint for now
    public ResponseEntity<AuthResponseDTO> register(@Valid @RequestBody AuthRequestDTO request)
    {
        AuthResponseDTO response = userService.registerUser(request);
        HttpStatus status = response.isSuccess() ? HttpStatus.CREATED : HttpStatus.BAD_REQUEST;
        return ResponseEntity.status(status).body(response);
    }

    // Google OAuth2 initiation endpoint
    @GetMapping("/google")
    public ResponseEntity<?> initiateGoogleLogin()
    {
        // This will redirect to Google OAuth
        return ResponseEntity.status(HttpStatus.FOUND)
                .header("Location", "/oauth2/authorization/google")
                .build();
    }

//    @PostMapping("/login") // old working endpoint
//    public ResponseEntity<AuthResponseDTO> login(@Valid @RequestBody AuthRequestDTO authRequestDTO)
//    {
//        Authentication authentication = authenticationManager.authenticate(
//                new UsernamePasswordAuthenticationToken(authRequestDTO.getEmail(), authRequestDTO.getPassword()));
//
//        SecurityContextHolder.getContext().setAuthentication(authentication);
//
//        User user = userRepository.findByEmail(authRequestDTO.getEmail())
//                .orElseThrow(() -> new RuntimeException("User not found"));
//
//        String jwt = jwtService.generateToken(user);
//        return ResponseEntity.ok(new AuthResponseDTO(jwt, user));
//    }

    @GetMapping("/me") // old working endpoint
    public ResponseEntity<User> getCurrentUser()
    {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated())
        {
            return ResponseEntity.status(401).build();
        }

        // Get the username (email) from authentication
        String email = authentication.getName();

        Optional<User> user = userRepository.findByEmail(email);
        return user.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

//    @PostMapping("/forgot-password")
//    public String forgotPassword(@RequestParam String email)
//    {
//        // Send reset link to local users only
//        if (userService.canUsePasswordLogin(email))
//        {
//            // Send reset email
//        }
//    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponseDTO> login(@Valid @RequestBody AuthRequestDTO req)
    {
        AuthResponseDTO response = userService.loginUser(req);
        HttpStatus status = response.isSuccess() ? HttpStatus.OK : HttpStatus.UNAUTHORIZED;
        return ResponseEntity.status(status).body(response);
    }

//    @GetMapping("/me")  // will use the old working endpoint for now, but I will test it later
//    public ResponseEntity<?> getCurrentUser(Authentication authentication)
//    {
//        try
//        {
//            User user = userService.getCurrentUser(authentication.getName());
//            return ResponseEntity.ok(user);
//        } catch (Exception e)
//        {
//            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
//                    .body(Map.of("success", false, "message", "User not authenticated"));
//        }
//    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request, HttpServletResponse response)
    {
        // JWT is stateless, so we just return success
        // Frontend should remove the token from storage
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Logout successful"
        ));
    }

    // Add this to your AuthController for testing
    @PostMapping("/test/google-user")
    public ResponseEntity<AuthResponseDTO> testGoogleUser()
    {
        // Simulate a Google user registration
        AuthResponseDTO response = userService.processOAuth2User(
                "sandeepduve@gmail.com",
                "Google Test User",
                "google-test-id-123"
        );
        return ResponseEntity.ok(response);
    }
}