package com.tenanttrust.service;

import com.tenanttrust.Exception.UserNotFoundException;
import com.tenanttrust.config.JwtService;
import com.tenanttrust.model.dto.AuthRequestDTO;
import com.tenanttrust.model.dto.AuthResponseDTO;
import com.tenanttrust.model.entities.User;
import com.tenanttrust.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserService
{
    @Autowired
    private final UserRepository userRepository;
    @Autowired
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtUtil;

    public void deleteUser(UUID userId)
    {
        User user = userRepository.findByIdNative(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + userId));

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        String currentUsername = authentication.getName();
        if (user.getUsername().equals(currentUsername))
        {
            throw new RuntimeException("Cannot delete your own account");
        }

        // Prevent deleting the last admin
        if ("ADMIN".equals(user.getRole()))
        {
            long adminCount = userRepository.countByRole("ADMIN");
            if (adminCount <= 1)
            {
                throw new RuntimeException("Cannot delete the last admin user");
            }
        }

        safeDeleteUser(user); // soft deletion

        // Option 2: Hard delete (permanent)
        //userRepository.deleteById(userId);
    }

    public void updateUserRole(UUID userId, String newRole)
    {
        User user = userRepository.findByIdNative(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + userId));

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();

        if (user.getUsername().equals(currentUsername))
        {
            throw new RuntimeException("Cannot change your own role");
        }

        // Prevent removing the last admin user
        if ("ADMIN".equals(user.getRole()) && !"ADMIN".equals(newRole))
        {
            long adminCount = userRepository.countByRole("ADMIN");
            if (adminCount <= 1)
            {
                throw new RuntimeException("Cannot remove the last admin user");
            }
        }

        user.setRole(User.UserRole.valueOf(newRole));
        userRepository.save(user);
    }

    public void updateUserProfile(UUID userId, User updatedUser)
    {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated())
        {
            throw new RuntimeException("Unauthorized");
        }

        // Get the username (email) from authentication
        String email = authentication.getName();

        Optional<User> user = userRepository.findByEmail(email);

        if (user.isEmpty() || !user.get().getId().equals(userId))
        {
            throw new RuntimeException("You can only update your own profile, you are logged in as: " + email + "");
        }

        User existingUser = userRepository.findByIdNative(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + userId));

        existingUser.setFullName(updatedUser.getFullName());
        existingUser.setPhoneNumber(updatedUser.getPhoneNumber());
        userRepository.save(existingUser);
    }

    public void changeUserPassword(UUID userId, String newPassword)
    {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated())
        {
            throw new RuntimeException("Unauthorized");
        }

        // Get the username (email) from authentication
        String email = authentication.getName();

        Optional<User> user = userRepository.findByEmail(email);

        if (user.isEmpty() || !user.get().getId().equals(userId))
        {
            throw new RuntimeException("You can only change your own password, you are logged in as: " + email + "");
        }

        User existingUser = userRepository.findByIdNative(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + userId));

        existingUser.setPassword(passwordEncoder.encode(newPassword));
        // existingUser.setPassword(newPassword); // In real application, hash the password before saving
        userRepository.save(existingUser);
    }

    private void safeDeleteUser(User user)
    {
        user.setEnabled(false);
        user.setDeleted(true);
        user.setDeletedAt(LocalDateTime.now());
        userRepository.save(user);
    }

//    private User getCurrentUser(String userEmail)
//    {
//        return userRepository.findByEmail(userEmail)
//                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
//    }

//    // Custom Registration
//    public User registerCustomUser(AuthRequestDTO registrationDTO)
//    {
//        // Check if email already exists
//        if (userRepository.existsByEmail(registrationDTO.getEmail()))
//        {
//            throw new EmailAlreadyExistsException("Email already registered: " + registrationDTO.getEmail());
//        }
//
//        User user = User.createLocalUser(
//                registrationDTO.getEmail(),
//                passwordEncoder.encode(registrationDTO.getPassword()),
//                registrationDTO.getFullName()
//        );
//
//        return userRepository.save(user);
//    }

    // OAuth2 Registration/Login
//    public AuthResponseDTO processOAuth2User(String email, String name, String googleId)
//    {
//        Optional<User> userOptional = userRepository.findByEmail(email);
//
//        if (userOptional.isPresent())
//        {
//            // User exists - update if needed
//            User user = userOptional.get();
//
//            // If local user tries to login with Google, link accounts
//            if ("local".equals(user.getProvider()))
//            {
//                user.setGoogleId(googleId);
//                user.setProvider("both"); // Can use both methods
//            }
//
//            user.setLastLogin(LocalDateTime.now());
//            return userRepository.save(user);
//
//        } else
//        {
//            // New user - register with Google
//            User newUser = User.createGoogleUser(email, name, googleId);
//            newUser.setLastLogin(LocalDateTime.now());
//            return userRepository.save(newUser);
//        }
//    }

    //

    // OAuth2 Processing - COMPLETE IMPLEMENTATION
    @Transactional
    public AuthResponseDTO processOAuth2User(String email, String name, String googleId)
    {
        try
        {
            Optional<User> userOptional = userRepository.findByEmail(email);
            User user;

            if (userOptional.isPresent())
            {
                user = userOptional.get();

                // Link accounts if local user uses Google
                if ("local".equals(user.getProvider()))
                {
                    user.setGoogleId(googleId);
                    user.setProvider("both");
                }

                user.setLastLogin(LocalDateTime.now());
                user = userRepository.save(user);

            } else
            {
                // New Google user
                user = User.createGoogleUser(email, name, googleId);
                user.setLastLogin(LocalDateTime.now());
            }
            User save = userRepository.save(user);

            String token = jwtUtil.generateToken(save);
            System.out.println("Generated Token: " + token);

            return AuthResponseDTO.success("Google login successful", token, AuthResponseDTO.fromUser(user));

        } catch (Exception e)
        {e.printStackTrace(); // See root cause
            return AuthResponseDTO.error("Google authentication failed: " + e.getMessage());
        }
    }

    public User getCurrentUser(String email)
    {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        return AuthResponseDTO.fromUser(user);
    }


    // Check if user can use password login
    public boolean canUsePasswordLogin(String email)
    {
        return userRepository.findByEmail(email)
                .map(user -> !"google".equals(user.getProvider()))
                .orElse(true); // New users can register
    }

    // Custom Registration - COMPLETE IMPLEMENTATION
    public AuthResponseDTO registerUser(AuthRequestDTO requestDTO)
    {
        try
        {
            if (userRepository.existsByEmail(requestDTO.getEmail()))
            {
                throw new RuntimeException("Email already registered");
            }
//             Validate password confirmation (you can add this to RegisterRequest)
            if (!requestDTO.getPassword().equals(requestDTO.getConfirmPassword()))
            {
                return AuthResponseDTO.error("Passwords do not match");
            }

            // Create and save user
            User user = User.createLocalUser(
                    requestDTO.getEmail(),
                    passwordEncoder.encode(requestDTO.getPassword()),
                    requestDTO.getFullName()
            );

            User savedUser = userRepository.save(user); // Save user to DB with tenant as default user role

            // Generate JWT token
            String token = jwtUtil.generateToken(savedUser);
            return AuthResponseDTO.success("Registration successful", token, savedUser);
//            return ResponseEntity.ok(new AuthResponseDTO(token, savedUser));
        } catch (Exception e)
        {
//            return ResponseEntity.badRequest("Registration failed: " + e.getMessage()+"");
            throw new RuntimeException("Registration failed: " + e.getMessage());
        }
    }

    // Custom Login - COMPLETE IMPLEMENTATION
    public AuthResponseDTO loginUser(AuthRequestDTO request)
    {
        try
        {
            User user = userRepository.findByEmail(request.getEmail())
                    .orElseThrow(() -> new UsernameNotFoundException("User not found"));

            // Check if user can use password login
            if ("google".equals(user.getProvider()))
            {
                return AuthResponseDTO.error("Please use Google Sign-In for this account");
            }

            // Verify password
            if (!passwordEncoder.matches(request.getPassword(), user.getPassword()))
            {
                return AuthResponseDTO.error("Invalid password");
            }

            // Update last login
            user.setLastLogin(LocalDateTime.now());
            userRepository.save(user);

            // Generate token
            String token = jwtUtil.generateToken(user);
            return AuthResponseDTO.success("Login successful", token, user); // need to check it for fromUser method, i deleted it

        } catch (UsernameNotFoundException e)
        {
            return AuthResponseDTO.error("Invalid email or password");
        } catch (Exception e)
        {
            return AuthResponseDTO.error("Login failed: " + e.getMessage());
        }
    }
}
