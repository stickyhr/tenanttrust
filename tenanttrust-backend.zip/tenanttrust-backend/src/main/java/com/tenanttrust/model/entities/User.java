package com.tenanttrust.model.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.UUID;

@Getter
@Setter
@Builder
@Entity
@Table(name = "users")
@SQLDelete(sql = "UPDATE users SET deleted = true WHERE id=?") // Override delete
@Where(clause = "deleted = false") // Filter deleted users automatically
public class User implements UserDetails
{
    public User(UUID id, UUID propertyId, String email, String password, String fullName, String phoneNumber, UserRole role, LocalDateTime createdAt, LocalDateTime updatedAt, boolean enabled, boolean deleted, LocalDateTime deletedAt, String googleId, String provider, String googlePassword)
    {
        this.id = id;
        this.propertyId = propertyId;
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.role = role;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.enabled = enabled;
        this.deleted = deleted;
        this.deletedAt = deletedAt;
        this.googleId = googleId;
        this.provider = provider;
        this.googlePassword = googlePassword;
    }

    public String getGooglePassword()
    {
        return googlePassword;
    }

    public void setGooglePassword(String googlePassword)
    {
        this.googlePassword = googlePassword;
    }

    public String getGoogleId()
    {
        return googleId;
    }

    public void setGoogleId(String googleId)
    {
        this.googleId = googleId;
    }

    public String getProvider()
    {
        return provider;
    }

    public void setProvider(String provider)
    {
        this.provider = provider;
    }

    public User(UUID id, UUID propertyId, String email, String password, String fullName, String phoneNumber, UserRole role, LocalDateTime createdAt, LocalDateTime updatedAt, boolean enabled, boolean deleted, LocalDateTime deletedAt, String googleId, String provider)
    {
        this.id = id;
        this.propertyId = propertyId;
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.role = role;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.enabled = enabled;
        this.deleted = deleted;
        this.deletedAt = deletedAt;
        this.googleId = googleId;
        this.provider = provider;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "property_id")
    private UUID propertyId;
    @Email
    @NotBlank
    @Column(unique = true)
    private String email;
    @NotBlank
    private String password;

    private String fullName;
    private String phoneNumber;
    @Enumerated(EnumType.STRING)
    private UserRole role = UserRole.TENANT;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    //    @Column(nullable = true) // ← Change to true temporarily
    private boolean enabled = true;
    //    @Column(nullable = true) // ← Change to true temporarily
    private boolean deleted = false;

    private LocalDateTime deletedAt;

    @Column(unique = true)
    private String googleId; // Store Google's user ID

    private String provider; // "google", "local", etc.

    private String googlePassword; // Null for Google users

    public void setLastLogin(LocalDateTime now)
    {
        updatedAt = LocalDateTime.now();
    }


    public enum UserRole
    {
        TENANT, LANDLORD, ADMIN
    }

    // Constructors, Getters, Setters
    @PrePersist
    protected void onCreate()
    {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }


    public UUID getPropertyId()
    {
        return propertyId;
    }

    public void setPropertyId(UUID propertyId)
    {
        this.propertyId = propertyId;
    }

    public void setEnabled(boolean enabled)
    {
        this.enabled = enabled;
    }

    public boolean isDeleted()
    {
        return deleted;
    }

    public void setDeleted(boolean deleted)
    {
        this.deleted = deleted;
    }

    public LocalDateTime getDeletedAt()
    {
        return deletedAt;
    }

    public void setDeletedAt(LocalDateTime deletedAt)
    {
        this.deletedAt = deletedAt;
    }

    public User(UUID id, UUID propertyId, String email, String password, String fullName, String phoneNumber, UserRole role, LocalDateTime createdAt, LocalDateTime updatedAt, boolean enabled, boolean deleted, LocalDateTime deletedAt)
    {
        this.id = id;
        this.propertyId = propertyId;
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.role = role;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.enabled = enabled;
        this.deleted = deleted;
        this.deletedAt = deletedAt;
    }

    public User(UUID id, UUID propertyId, String email, String password, String fullName, String phoneNumber, UserRole role, LocalDateTime createdAt, LocalDateTime updatedAt)
    {
        this.id = id;
        this.propertyId = propertyId;
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.role = role;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }


    public User()
    {

    }

    public User(UUID id, String email, String password, String fullName, String phoneNumber, UserRole role, LocalDateTime createdAt, LocalDateTime updatedAt)
    {
        this.id = id;
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.role = role;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public UUID getId()
    {
        return id;
    }

    public void setId(UUID id)
    {
        this.id = id;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }

    public String getFullName()
    {
        return fullName;
    }

    public void setFullName(String fullName)
    {
        this.fullName = fullName;
    }

    public String getPhoneNumber()
    {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }

    public UserRole getRole()
    {
        return role;
    }

    public void setRole(UserRole role)
    {
        this.role = role;
    }

    public LocalDateTime getCreatedAt()
    {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt)
    {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt()
    {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt)
    {
        this.updatedAt = updatedAt;
    }


    @PreUpdate
    protected void onUpdate()
    {
        updatedAt = LocalDateTime.now();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities()
    {
        return Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role.name()));
    }

    @Override
    public String getPassword()
    {
        return password;
    }

    @Override
    public String getUsername()
    {
        return email;
    }

    @Override
    public boolean isAccountNonExpired()
    {
        return true;
    }

    @Override
    public boolean isAccountNonLocked()
    {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired()
    {
        return true;
    }

    @Override
    public boolean isEnabled()
    {
        return true;
    }

    // Constructors for different auth types
    public static User createLocalUser(String email, String password, String fullName)
    {
        User user = new User();
        user.setEmail(email);
        user.setPassword(password); // Will be encoded
        user.setFullName(fullName);
        user.setProvider("local");
        user.setRole(User.UserRole.TENANT); // Default role will be TENANT
        user.setCreatedAt(LocalDateTime.now());
        return user;
    }

    public static User createGoogleUser(String email, String fullName, String googleId)
    {
        User user = new User();
        user.setEmail(email);
        String rndm = UUID.randomUUID().toString();
        System.out.println("Generated dummy password for Google user: " + rndm); // need to clear this log later, as it is sensitive info
        user.setPassword(rndm); // dummy password for @NotBlank
        user.setFullName(fullName);
        user.setGoogleId(googleId);
        user.setProvider("google");
        user.setRole(User.UserRole.TENANT); // Default role will be TENANT even if login via Google
        user.setCreatedAt(LocalDateTime.now());
        return user;
    }

}