package com.tenanttrust.model.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@Builder
@Entity
@Table(name = "properties")
public class Property
{
    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public Property(String userFullName, UUID id, User userId, String email, String addressLine1, String addressLine2, String propertyName, String locality, String city, String pincode, BigDecimal latitude, BigDecimal longitude, PropertyType propertyType, Boolean isVerified, BigDecimal aggregatedRating, Integer reviewCount, User createdBy, Boolean isActive, LocalDateTime createdAt, LocalDateTime updatedAt, String description)
    {
        this.userFullName = userFullName;
        this.id = id;
        this.userId = userId;
        this.email = email;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.propertyName = propertyName;
        this.locality = locality;
        this.city = city;
        this.pincode = pincode;
        this.latitude = latitude;
        this.longitude = longitude;
        this.propertyType = propertyType;
        this.isVerified = isVerified;
        this.aggregatedRating = aggregatedRating;
        this.reviewCount = reviewCount;
        this.createdBy = createdBy;
        this.isActive = isActive;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.description = description;
    }

    public String getUserEmail()
    {
        return email;
    }

    public String setUserEmail(String userEmail)
    {
        return this.email = userEmail;
    }

    public String setUserFullName(String userFullName)
    {
        return this.userFullName = userFullName;
    }

    public String getUserFullName()
    {
        return userFullName;
    }

    private String userFullName;

    public Property(UUID id, User userId, String userEmail, String userFullName, String addressLine1, String addressLine2, String propertyName, String locality, String city, String pincode, BigDecimal latitude, BigDecimal longitude, PropertyType propertyType, Boolean isVerified, BigDecimal aggregatedRating, Integer reviewCount, User createdBy, Boolean isActive, LocalDateTime createdAt, LocalDateTime updatedAt, String description)
    {
        this.id = id;
        this.userId = userId;
        this.email = userEmail;
        this.userFullName = userFullName;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.propertyName = propertyName;
        this.locality = locality;
        this.city = city;
        this.pincode = pincode;
        this.latitude = latitude;
        this.longitude = longitude;
        this.propertyType = propertyType;
        this.isVerified = isVerified;
        this.aggregatedRating = aggregatedRating;
        this.reviewCount = reviewCount;
        this.createdBy = createdBy;
        this.isActive = isActive;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.description = description;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnore
    private User userId;

    private String email;

    @NotBlank
    private String addressLine1;
    private String addressLine2;

    @NotBlank
    private String propertyName;

    @NotBlank
    private String locality;

    @NotBlank
    private String city;

    @NotBlank
    private String pincode;

    private BigDecimal latitude;
    private BigDecimal longitude;

    @Enumerated(EnumType.STRING)
    private PropertyType propertyType;

    private Boolean isVerified = false;
    private BigDecimal aggregatedRating = BigDecimal.ZERO;
    private Integer reviewCount = 0;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    @JsonIgnore
    private User createdBy;

    private Boolean isActive = true;

    @CreationTimestamp
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    private String description;

    public Property(UUID id, User userId, String addressLine1, String addressLine2, String propertyName, String locality, String city, String pincode, BigDecimal latitude, BigDecimal longitude, PropertyType propertyType, Boolean isVerified, BigDecimal aggregatedRating, Integer reviewCount, User createdBy, Boolean isActive, LocalDateTime createdAt, LocalDateTime updatedAt, String description)
    {
        this.id = id;
        this.userId = userId;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.propertyName = propertyName;
        this.locality = locality;
        this.city = city;
        this.pincode = pincode;
        this.latitude = latitude;
        this.longitude = longitude;
        this.propertyType = propertyType;
        this.isVerified = isVerified;
        this.aggregatedRating = aggregatedRating;
        this.reviewCount = reviewCount;
        this.createdBy = createdBy;
        this.isActive = isActive;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.description = description;
    }

    public UUID getId()
    {
        return id;
    }

    public void setId(UUID id)
    {
        this.id = id;
    }

    public String getPropertyName()
    {
        return propertyName;
    }

    public void setPropertyName(String propertyName)
    {
        this.propertyName = propertyName;
    }

    public String getAddressLine1()
    {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1)
    {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2()
    {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2)
    {
        this.addressLine2 = addressLine2;
    }

    public String getLocality()
    {
        return locality;
    }

    public void setLocality(String locality)
    {
        this.locality = locality;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getPincode()
    {
        return pincode;
    }

    public void setPincode(String pincode)
    {
        this.pincode = pincode;
    }

    public BigDecimal getLatitude()
    {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude)
    {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude()
    {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude)
    {
        this.longitude = longitude;
    }

    public PropertyType getPropertyType()
    {
        return propertyType;
    }

    public void setPropertyType(PropertyType propertyType)
    {
        this.propertyType = propertyType;
    }

    public Boolean getVerified()
    {
        return isVerified;
    }

    public void setVerified(Boolean verified)
    {
        isVerified = verified;
    }

    public BigDecimal getAggregatedRating()
    {
        return aggregatedRating;
    }

    public void setAggregatedRating(BigDecimal aggregatedRating)
    {
        this.aggregatedRating = aggregatedRating;
    }

    public Integer getReviewCount()
    {
        return reviewCount;
    }

    public void setReviewCount(Integer reviewCount)
    {
        this.reviewCount = reviewCount;
    }

    public Property()
    {
    }

    public User getUserId()
    {
        return userId;
    }

    public void setUserId(User userId)
    {
        this.userId = userId;
    }

    public User getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(User createdBy)
    {
        this.createdBy = createdBy;
    }

    public Boolean getActive()
    {
        return isActive;
    }

    public void setActive(Boolean active)
    {
        isActive = active;
    }

    public LocalDateTime getCreatedAt()
    {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt)
    {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt()
    {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt)
    {
        this.updatedAt = updatedAt;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public enum PropertyType
    {
        APARTMENT("APPARTMENT"), INDEPENDENT_HOUSE("INDEPENDENT HOUSE"),
        Independent_House("Independent House"),VILLA("VILLA"),
        COMMERCIAL("commercial"), PG_HOSTEL("PG/Hostel");
        String pType;
        PropertyType(String propertyType)
        {
            pType = propertyType;
        }
        public String getPropertyType()
        {
            return pType;
        }
    }
}