package com.tenanttrust.controller;

import com.tenanttrust.model.dto.ReviewDTO;
import com.tenanttrust.model.entities.User;
import com.tenanttrust.repository.UserRepository;
import com.tenanttrust.service.PropertyService;
import com.tenanttrust.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/reviews")
@CrossOrigin(origins = "http://localhost:3000")
public class ReviewController
{
    @Autowired
    private final ReviewService reviewService;
    @Autowired
    private final UserRepository userRepository;

    @Autowired
    private final PropertyService propertyService;

    @Autowired  // optional if only one constructor
    public ReviewController(ReviewService reviewService, UserRepository userRepository, PropertyService propertyService)
    {
        this.reviewService = reviewService;
        this.userRepository = userRepository;
        this.propertyService = propertyService;
    }

    @PostMapping("/create")
    public ResponseEntity<ReviewDTO.ReviewResponse> createReview(@RequestBody ReviewDTO.CreateReviewRequest reviewDTO)
    {
        User usermail = userRepository.findByEmail(SecurityContextHolder.getContext().getAuthentication().getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        ReviewDTO.ReviewResponse response = reviewService.createReview(reviewDTO, String.valueOf(usermail.getEmail()));
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }


    @GetMapping("/property/{propertyId}")
    public ResponseEntity<List<ReviewDTO.ReviewResponse>> getPropertyReviews(@PathVariable UUID propertyId)
    {
        List<ReviewDTO.ReviewResponse> reviews = reviewService.getReviewsByPropertyId(propertyId);
        return ResponseEntity.ok(reviews);
    }

//
//    @GetMapping("/pending")
//    public ResponseEntity<List<ReviewResponseDTO>> getPendingReviews() {
//        List<ReviewResponseDTO> reviews = reviewService.getPendingReviews();
//        return ResponseEntity.ok(reviews);
//    }
//
//    @PatchMapping("/{reviewId}/approve")
//    public ResponseEntity<ApiResponse> approveReview(@PathVariable UUID reviewId)
//    {
//        ApiResponse response = reviewService.approveReview(reviewId);
//        return ResponseEntity.ok(response);
//    }

    @GetMapping("/check")
    public ResponseEntity<Boolean> checkUserReview(@RequestParam UUID propertyId, @AuthenticationPrincipal User userId)
    {
        boolean hasReviewed = reviewService.hasUserReviewedProperty(propertyId, userId.getId());
        return ResponseEntity.ok(hasReviewed);
    }

}