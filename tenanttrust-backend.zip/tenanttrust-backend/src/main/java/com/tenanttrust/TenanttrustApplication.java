package com.tenanttrust;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TenanttrustApplication
{

	public static void main(String[] args) {
		SpringApplication.run(TenanttrustApplication.class, args);
	}

}
