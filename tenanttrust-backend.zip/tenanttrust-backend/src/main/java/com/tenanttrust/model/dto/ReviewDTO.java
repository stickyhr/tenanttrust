package com.tenanttrust.model.dto;

import com.tenanttrust.model.entities.Review;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
public class ReviewDTO
{
    public static class CreateReviewRequest
    {
        @NotNull(message = "Property ID is required")
        private UUID propertyId;

        @NotNull(message = "Overall rating is required")
        @Min(1)
        @Max(5)
        private Integer rating;

        @NotNull(message = "Maintenance rating is required")
        @Min(1)
        @Max(5)
        private Integer maintenance;

        @NotNull(message = "Communication rating is required")
        @Min(1)
        @Max(5)
        private Integer communication;

        @NotNull(message = "Value rating is required")
        @Min(1)
        @Max(5)
        private Integer value;

        // Anonymous tenant info (never reveal real details)
        private String tenantDisplayName;
        private Boolean isAnonymous;

        @Size(max = 1000, message = "Pros must be less than 1000 characters")
        private String pros;

        @Size(max = 1000, message = "Cons must be less than 1000 characters")
        private String cons;

        private LocalDate tenureStart;
        private LocalDate tenureEnd;

        public CreateReviewRequest(UUID propertyId, Integer rating, Integer maintenance, Integer communication,
                                   Integer value, String pros, String cons, LocalDate tenureStart, LocalDate tenureEnd,
                                   Review.ReviewScope reviewScope)
        {
            this.propertyId = propertyId;
            this.rating = rating;
            this.maintenance = maintenance;
            this.communication = communication;
            this.value = value;
            this.pros = pros;
            this.cons = cons;
            this.tenureStart = tenureStart;
            this.tenureEnd = tenureEnd;
//            this.useremail = useremail;
            this.reviewScope = reviewScope;
        }

        @NotNull(message = "Review scope is required")
        private Review.ReviewScope reviewScope;

        // Getters and Setters
        public UUID getPropertyId()
        {
            return propertyId;
        }

        public void setPropertyId(UUID propertyId)
        {
            this.propertyId = propertyId;
        }

        public Integer getRating()
        {
            return rating;
        }

        public void setRating(Integer rating)
        {
            this.rating = rating;
        }

        public Integer getMaintenance()
        {
            return maintenance;
        }

        public void setMaintenance(Integer maintenance)
        {
            this.maintenance = maintenance;
        }

        public Integer getCommunication()
        {
            return communication;
        }

        public void setCommunication(Integer communication)
        {
            this.communication = communication;
        }

        public Integer getValue()
        {
            return value;
        }

        public void setValue(Integer value)
        {
            this.value = value;
        }

        public String getPros()
        {
            return pros;
        }

        public void setPros(String pros)
        {
            this.pros = pros;
        }

        public String getCons()
        {
            return cons;
        }

        public void setCons(String cons)
        {
            this.cons = cons;
        }

        public LocalDate getTenureStart()
        {
            return tenureStart;
        }

        public void setTenureStart(LocalDate tenureStart)
        {
            this.tenureStart = tenureStart;
        }

        public LocalDate getTenureEnd()
        {
            return tenureEnd;
        }

        public void setTenureEnd(LocalDate tenureEnd)
        {
            this.tenureEnd = tenureEnd;
        }

        public Review.ReviewScope getReviewScope()
        {
            return reviewScope;
        }

        public void setReviewScope(Review.ReviewScope reviewScope)
        {
            this.reviewScope = reviewScope;
        }
    }

    public static class ReviewResponse
    {
        private UUID id;
        private UUID propertyId;
        private String userEmail;
        private String userName;
        private Integer rating;
        private Integer maintenance;
        private Integer communication;
        private Integer value;
        private String pros;
        private String cons;
        private LocalDate tenureStart;
        private LocalDate tenureEnd;
        private Review.ReviewScope reviewScope;
        private String createdAt;
        private String updatedAt;

        // Constructors
        public ReviewResponse()
        {
        }

        // Getters and Setters
        public UUID getId()
        {
            return id;
        }

        public void setId(UUID id)
        {
            this.id = id;
        }

        public UUID getPropertyId()
        {
            return propertyId;
        }

        public void setPropertyId(UUID propertyId)
        {
            this.propertyId = propertyId;
        }

        public String getUserEmail()
        {
            return userEmail;
        }

        public void setUserEmail(String userEmail)
        {
            this.userEmail = userEmail;
        }

        public String getUserName()
        {
            return userName;
        }

        public void setUserName(String userName)
        {
            this.userName = userName;
        }

        public Integer getRating()
        {
            return rating;
        }

        public void setRating(Integer rating)
        {
            this.rating = rating;
        }

        public Integer getMaintenance()
        {
            return maintenance;
        }

        public void setMaintenance(Integer maintenance)
        {
            this.maintenance = maintenance;
        }

        public Integer getCommunication()
        {
            return communication;
        }

        public void setCommunication(Integer communication)
        {
            this.communication = communication;
        }

        public Integer getValue()
        {
            return value;
        }

        public void setValue(Integer value)
        {
            this.value = value;
        }

        public String getPros()
        {
            return pros;
        }

        public void setPros(String pros)
        {
            this.pros = pros;
        }

        public String getCons()
        {
            return cons;
        }

        public void setCons(String cons)
        {
            this.cons = cons;
        }

        public LocalDate getTenureStart()
        {
            return tenureStart;
        }

        public void setTenureStart(LocalDate tenureStart)
        {
            this.tenureStart = tenureStart;
        }

        public LocalDate getTenureEnd()
        {
            return tenureEnd;
        }

        public void setTenureEnd(LocalDate tenureEnd)
        {
            this.tenureEnd = tenureEnd;
        }

        public Review.ReviewScope getReviewScope()
        {
            return reviewScope;
        }

        public void setReviewScope(Review.ReviewScope reviewScope)
        {
            this.reviewScope = reviewScope;
        }

        public String getCreatedAt()
        {
            return createdAt;
        }

        public void setCreatedAt(String createdAt)
        {
            this.createdAt = createdAt;
        }

        public String getUpdatedAt()
        {
            return updatedAt;
        }

        public void setUpdatedAt(String updatedAt)
        {
            this.updatedAt = updatedAt;
        }
    }

    public static class PropertyReviewsResponse
    {
        private Double averageRating;
        private Double averageMaintenance;
        private Double averageCommunication;
        private Double averageValue;
        private Integer totalReviews;
        private java.util.List<ReviewResponse> reviews;

        // Getters and Setters
        public Double getAverageRating()
        {
            return averageRating;
        }

        public void setAverageRating(Double averageRating)
        {
            this.averageRating = averageRating;
        }

        public Double getAverageMaintenance()
        {
            return averageMaintenance;
        }

        public void setAverageMaintenance(Double averageMaintenance)
        {
            this.averageMaintenance = averageMaintenance;
        }

        public Double getAverageCommunication()
        {
            return averageCommunication;
        }

        public void setAverageCommunication(Double averageCommunication)
        {
            this.averageCommunication = averageCommunication;
        }

        public Double getAverageValue()
        {
            return averageValue;
        }

        public void setAverageValue(Double averageValue)
        {
            this.averageValue = averageValue;
        }

        public Integer getTotalReviews()
        {
            return totalReviews;
        }

        public void setTotalReviews(Integer totalReviews)
        {
            this.totalReviews = totalReviews;
        }

        public java.util.List<ReviewResponse> getReviews()
        {
            return reviews;
        }

        public void setReviews(java.util.List<ReviewResponse> reviews)
        {
            this.reviews = reviews;
        }
    }

    public class ReviewSummaryDTO
    {
        private UUID id;
        private String comment;
        private String pros;
        private String cons;
        private Integer rating;
        private String tenantName;
        private LocalDateTime createdAt;

        public ReviewSummaryDTO(Review review)
        {
            this.id = review.getId();
            this.pros = review.getPros();
            this.cons = review.getCons();
            this.rating = review.getRating(); // need to look rating data type, rating is Integer
            this.tenantName = "ananymous user";
            this.createdAt = review.getCreatedAt();
        }
    }
}