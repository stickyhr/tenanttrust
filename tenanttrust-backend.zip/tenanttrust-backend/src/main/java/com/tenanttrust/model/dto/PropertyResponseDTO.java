package com.tenanttrust.model.dto;

import com.tenanttrust.model.entities.Property;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PropertyResponseDTO
{
    private UUID id;
    private String propertyName;
    private String addressLine1;
    private String addressLine2;
    private String locality;
    private String city;
    private String pincode;
    private Property.PropertyType propertyType;
    private String description;
    private String createdBy;
    private LocalDateTime createdAt;
    private Integer reviewCount;

    public PropertyResponseDTO()
    {

    }

    public String getUserFullName()
    {
        return userFullName;
    }

    public void setUserFullName(String userFullName)
    {
        this.userFullName = userFullName;
    }

    private BigDecimal latitude;
    private BigDecimal longitude;

    private Boolean isVerified;
    private BigDecimal aggregatedRating;
    private Boolean isActive;
    private LocalDateTime updatedAt;
    private String userFullName;

    // NEW: Add recent reviews preview
    private List<ReviewDTO.ReviewSummaryDTO> recentReviews;

    private String useremail;

    public PropertyResponseDTO(UUID id, String propertyName, String addressLine1, String addressLine2, String locality, String city, String pincode, Property.PropertyType propertyType, String description, String createdBy, LocalDateTime createdAt, Integer reviewCount, BigDecimal latitude, BigDecimal longitude, Boolean isVerified, BigDecimal aggregatedRating, Boolean isActive, LocalDateTime updatedAt, String userFullName, List<ReviewDTO.ReviewSummaryDTO> recentReviews, String useremail)
    {
        this.id = id;
        this.propertyName = propertyName;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.locality = locality;
        this.city = city;
        this.pincode = pincode;
        this.propertyType = propertyType;
        this.description = description;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.reviewCount = reviewCount;
        this.latitude = latitude;
        this.longitude = longitude;
        this.isVerified = isVerified;
        this.aggregatedRating = aggregatedRating;
        this.isActive = isActive;
        this.updatedAt = updatedAt;
        this.userFullName = userFullName;
        this.recentReviews = recentReviews;
        this.useremail = useremail;
    }

    public PropertyResponseDTO(Property property)
    {
        this.id = property.getId();
        this.propertyName = property.getPropertyName();
        this.description = property.getDescription();
        this.addressLine1 = property.getAddressLine1();
        this.addressLine2 = property.getAddressLine2();
        this.locality = property.getLocality();
        this.city = property.getCity();
        this.pincode = property.getPincode();
        this.latitude = property.getLatitude();
        this.longitude = property.getLongitude();
        this.propertyType = property.getPropertyType();
        this.isVerified = property.getIsVerified();
        this.aggregatedRating = property.getAggregatedRating();
        this.reviewCount = property.getReviewCount();
        this.createdBy = property.getCreatedBy() != null ? property.getCreatedBy().getEmail() : null;
        this.isActive = property.getIsActive();
        this.createdAt = property.getCreatedAt();
        this.updatedAt = property.getUpdatedAt();
        this.userFullName = property.getUserId().getFullName();
        this.useremail = property.getUserId().getEmail();
        this.recentReviews = new ArrayList<>(); // Will be populated separately
    }

    public UUID getId()
    {
        return id;
    }

    public void setId(UUID id)
    {
        this.id = id;
    }

    public String getPropertyName()
    {
        return propertyName;
    }

    public void setPropertyName(String propertyName)
    {
        this.propertyName = propertyName;
    }

    public String getAddressLine1()
    {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1)
    {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2()
    {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2)
    {
        this.addressLine2 = addressLine2;
    }

    public String getLocality()
    {
        return locality;
    }

    public void setLocality(String locality)
    {
        this.locality = locality;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getPincode()
    {
        return pincode;
    }

    public void setPincode(String pincode)
    {
        this.pincode = pincode;
    }

    public Property.PropertyType getPropertyType()
    {
        return propertyType;
    }

    public void setPropertyType(Property.PropertyType propertyType)
    {
        this.propertyType = propertyType;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreatedAt()
    {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt)
    {
        this.createdAt = createdAt;
    }

    public Integer getReviewCount()
    {
        return reviewCount;
    }

    public void setReviewCount(Integer reviewCount)
    {
        this.reviewCount = reviewCount;
    }


}