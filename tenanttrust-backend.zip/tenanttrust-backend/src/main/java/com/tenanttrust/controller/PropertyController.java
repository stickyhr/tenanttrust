package com.tenanttrust.controller;

import com.tenanttrust.Exception.UserNotFoundException;
import com.tenanttrust.model.dto.ApiResponse;
import com.tenanttrust.model.dto.PropertiesRequestDTO;
import com.tenanttrust.model.dto.PropertyResponseDTO;
import com.tenanttrust.model.entities.Property;
import com.tenanttrust.model.entities.User;
import com.tenanttrust.repository.PropertyRepository;
import com.tenanttrust.repository.UserRepository;
import com.tenanttrust.service.PropertyService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/properties")
@CrossOrigin(origins = "http://localhost:3000")
public class PropertyController
{
    private final PropertyRepository propertyRepository;
    private final PropertyService propertyService;
    private final UserRepository userRepository;

    @Autowired   // optional in Spring Boot if only one constructor
    public PropertyController(PropertyRepository propertyRepository, PropertyService propertyService, UserRepository userRepository)
    {
        this.propertyRepository = propertyRepository;
        this.propertyService = propertyService;
        this.userRepository = userRepository;
    }

    @PostMapping("/add-property")
//    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PropertyResponseDTO> addProperties(@Valid @RequestBody PropertiesRequestDTO propertiesRequestDTO,
                                                             @AuthenticationPrincipal String admin)
    {
        User user = userRepository.findByEmail(SecurityContextHolder.getContext().getAuthentication().getName())
                .orElseThrow(() -> new UserNotFoundException("User with Admin Role not found"));

        PropertyResponseDTO property = propertyService.createProperty(propertiesRequestDTO, user.getId());
        return ResponseEntity.status(HttpStatus.CREATED).body(property);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Property>> getAllProperties()
    {
        List<Property> prop = propertyRepository.findAllProperties();
        return ResponseEntity.ok(prop);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Property> getPropertyById(@PathVariable UUID id)
    {
        return propertyRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/top-rated")
    public ResponseEntity<List<Property>> getTopRatedProperties()
    {
        List<Property> properties = propertyRepository.findTopRatedProperties();
        return ResponseEntity.ok(properties);
    }

    // ADMIN ONLY: Verify property -- putting this on hold for now, as admin only add property, so they should be verified by default
//    @PutMapping("/verify/{propertyId}")
//    @PreAuthorize("hasRole('ADMIN')")
//    public ResponseEntity<Property> verifyProperty(@PathVariable UUID propertyId, @AuthenticationPrincipal User admin)
//    {
//        Property property = propertyService.verifyProperty(propertyId, admin.getId());
//        return ResponseEntity.ok(property);
//    }


    @GetMapping("/city/{city}")
    public ResponseEntity<List<Property>> getPropertiesByCity(@PathVariable String city)
    {
        List<Property> properties = propertyRepository.findByCityAndIsActive(city, true);
        return ResponseEntity.ok(properties);
    }

    // ADMIN ONLY: Update property
    @PutMapping("/update/{propertyId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PropertyResponseDTO> updateProperty(@PathVariable UUID propertyId, @Valid @RequestBody PropertiesRequestDTO request,
                                                              @AuthenticationPrincipal User user)
    {

        PropertyResponseDTO property = propertyService.updateProperty(propertyId, request, user.getId());
        return ResponseEntity.ok(property);
    }

    // ADMIN ONLY: Deactivate property
    @DeleteMapping("deactivate/{propertyId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse> deactivateProperty(@PathVariable UUID propertyId, @AuthenticationPrincipal User user)
    {
        user = userRepository.findByEmail(SecurityContextHolder.getContext().getAuthentication().getName())
                .orElseThrow(() -> new UserNotFoundException("User with Admin Role not found to deactivate property"));

        boolean isPropertyDeactivatedAlready = propertyService.deactivateProperty(propertyId, user.getId());
        if (!isPropertyDeactivatedAlready)
        {
            ApiResponse response = new ApiResponse(false, "Property is already de-activated!");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
        return ResponseEntity.ok(new ApiResponse(true, "Property deactivated successfully"));
    }


    // ADMIN ONLY: Reactivate property
    @PatchMapping("reactivate/{propertyId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse> reactivateProperty(@PathVariable UUID propertyId, @AuthenticationPrincipal User user)
    {
        user = userRepository.findByEmail(SecurityContextHolder.getContext().getAuthentication().getName())
                .orElseThrow(() -> new UserNotFoundException("User with Admin Role not found to deactivate property"));

        boolean isPropertyDeactivatedAlready = propertyService.reActivateProperty(propertyId, user.getId());
        if (!isPropertyDeactivatedAlready)
        {
            ApiResponse response = new ApiResponse(true, "Property is already re-activated!");
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }
        return ResponseEntity.ok(new ApiResponse(true, "Property re-activated successfully"));
    }


    // NEW: Search endpoints
    @GetMapping("/search")
    public ResponseEntity<Page<PropertyResponseDTO>> searchProperties(
            @RequestParam(required = false) String city,
            @RequestParam(required = false) String pincode,
            @RequestParam(required = false) String locality,
            @RequestParam(required = false) Property.PropertyType propertyType,
            @RequestParam(required = false) Boolean verifiedOnly,
            @RequestParam(defaultValue = "0") Integer page,
            @RequestParam(defaultValue = "20") Integer size)
    {

        PropertiesRequestDTO searchRequest = new PropertiesRequestDTO();
        searchRequest.setSearchCity(city);
        searchRequest.setSearchPincode(pincode);
        searchRequest.setSearchLocality(locality);
        searchRequest.setSearchPropertyType(propertyType);
        searchRequest.setSearchVerifiedOnly(verifiedOnly);
        searchRequest.setPage(page);
        searchRequest.setSize(size);

        Page<PropertyResponseDTO> results = propertyService.searchProperties(searchRequest);
        return ResponseEntity.ok(results);
    }

    @GetMapping("/search/simple")
    public ResponseEntity<List<PropertyResponseDTO>> simpleSearch(@RequestParam String query)
    {
        List<PropertyResponseDTO> results = propertyService.simpleSearch(query);
        return ResponseEntity.ok(results);
    }

    @GetMapping("/pincode/{pincode}")
    public ResponseEntity<List<PropertyResponseDTO>> getPropertiesByPincode(@PathVariable String pincode)
    {
        List<PropertyResponseDTO> results = propertyService.getPropertiesByPincode(pincode);
        return ResponseEntity.ok(results);
    }

    // Your existing helper methods...
    private Property convertToEntity(PropertiesRequestDTO dto)
    {
        // Your existing conversion logic
        return Property.builder()
                .propertyName(dto.getPropertyName())
                .addressLine1(dto.getAddressLine1())
                // ... other fields
                .build();
    }
}