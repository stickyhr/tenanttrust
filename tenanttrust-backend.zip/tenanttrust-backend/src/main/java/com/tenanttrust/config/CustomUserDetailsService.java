package com.tenanttrust.config;

import com.tenanttrust.model.entities.User;
import com.tenanttrust.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService
{

    private final UserRepository userRepository;

    @Autowired   // optional since Spring 4.3+
    public CustomUserDetailsService(UserRepository userRepository)
    {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException
    {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + email));

        // Check if user is a Google user trying to use form login
        if ("google".equals(user.getProvider()))
        {
            throw new UsernameNotFoundException("Google user must use Google Sign-In");
        }

        return user;
    }
}