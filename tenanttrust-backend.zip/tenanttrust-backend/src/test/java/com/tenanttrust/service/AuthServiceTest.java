package com.tenanttrust.service;

public class AuthServiceTest
{
}
