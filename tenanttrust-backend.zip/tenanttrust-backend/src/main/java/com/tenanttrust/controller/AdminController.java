//package com.tenanttrust.controller;
//
//import com.tenanttrust.model.entities.User;
//import com.tenanttrust.repository.UserRepository;
//import com.tenanttrust.service.UserService;
//import lombok.RequiredArgsConstructor;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//import java.util.UUID;
//
//@RestController
//@RequestMapping("/api/admin")
//@RequiredArgsConstructor
//@CrossOrigin(origins = "http://localhost:3000")
//public class AdminController
//{
//    private final UserRepository userRepository;
//    private final UserService userService;
//
////    // Manual constructor injection
////    @Autowired
////    public AdminController(UserRepository userRepository)
////    {
////        this.userRepository = userRepository;
////    }
//
////    @GetMapping("/users")
////    @PreAuthorize("hasRole('ADMIN')")
////    public ResponseEntity<List<User>> getAllUsers()
////    {
////        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
////
////        if (authentication == null || !authentication.isAuthenticated())
////        {
////            return ResponseEntity.status(401).build();
////        }
////        List<User> user = userRepository.findAll();
////        return ResponseEntity.ok(user);
////    }
//
////    @DeleteMapping("/users/{id}")
////    @PreAuthorize("hasRole('ADMIN')")
////    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
////        Optional<User> userOptional = userRepository.findById(id);
////        if (userOptional.isPresent()) {
////            userRepository.deleteById(id);
////            return ResponseEntity.noContent().build();
////        } else {
////            return ResponseEntity.notFound().build();
////        }
////    }
//
//
////    @DeleteMapping("delete/user/{id}")
////    @PreAuthorize("hasRole('ADMIN')")
////    public ResponseEntity<Void> deleteUsers(@PathVariable UUID id)
////    {
////        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
////        if(authentication == null || !authentication.isAuthenticated())
////        {
////            return ResponseEntity.status(401).build();
////        }
////
////        userService.deleteUser(id);
////
////        return ResponseEntity.noContent().build();
////    }
//
//}