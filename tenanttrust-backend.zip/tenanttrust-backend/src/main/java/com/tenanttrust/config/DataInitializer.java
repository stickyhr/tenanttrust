package com.tenanttrust.config;

import com.tenanttrust.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner
{

    private final UserRepository userRepository;
//    private final PropertyRepository propertyRepository;
//    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder)
    {
        this.userRepository = userRepository;
//        this.propertyRepository = propertyRepository;
//        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception
    {
        // Create admin user
//        if (userRepository.findByEmail("master@tenanttrust.com").isEmpty()) {
//            User admin = new User();
//            admin.setEmail("master@tenanttrust.com");
////            admin.setPassword(passwordEncoder.encode("master123"));
//            admin.setFullName("System Admin");
//            admin.setRole(User.UserRole.ADMIN);
//            userRepository.save(admin);
    }

    // Create sample properties
//        if (propertyRepository.count() == 0) {
//            Property property1 = new Property();
//            property1.setPropertyName("Prestige Falcon City");
//            property1.setAddressLine1("123 Main Road");
//            property1.setLocality("Brookefield");
//            property1.setCity("Bangalore");
//            property1.setPincode("560066");
//            property1.setLatitude(new BigDecimal("12.9360"));
//            property1.setLongitude(new BigDecimal("77.6890"));
//            property1.setPropertyType(Property.PropertyType.APARTMENT);
//          //  propertyRepository.save(property1);
//
//            Property property2 = new Property();
//            property2.setPropertyName("Brigade Metropolis");
//            property2.setAddressLine1("456 MG Road");
//            property2.setLocality("Mahadevapura");
//            property2.setCity("Bangalore");
//            property2.setPincode("560048");
//            property2.setLatitude(new BigDecimal("12.9910"));
//            property2.setLongitude(new BigDecimal("77.6970"));
//            property2.setPropertyType(Property.PropertyType.APARTMENT);
//           // propertyRepository.save(property2);
//        }
}
//}