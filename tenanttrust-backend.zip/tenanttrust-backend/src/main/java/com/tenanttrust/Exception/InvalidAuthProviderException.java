package com.tenanttrust.Exception;

public class InvalidAuthProviderException
    extends RuntimeException{
    public InvalidAuthProviderException(String message)
    {
        super(message);
    }
}
