-- Add new columns
ALTER TABLE users
ADD COLUMN enabled BOOLEAN,
ADD COLUMN deleted BOOLEAN,
ADD COLUMN deleted_at TIMESTAMP;

-- Set default values for existing records
UPDATE users SET enabled = TRUE WHERE enabled IS NULL;
UPDATE users SET deleted = FALSE WHERE deleted IS NULL;

-- Make columns NOT NULL after setting defaults
ALTER TABLE users
ALTER COLUMN enabled SET NOT NULL,
ALTER COLUMN deleted SET NOT NULL;

-- Add constraint if needed
ALTER TABLE users ADD CONSTRAINT users_enabled_default DEFAULT TRUE FOR enabled;
ALTER TABLE users ADD CONSTRAINT users_deleted_default DEFAULT FALSE FOR deleted;