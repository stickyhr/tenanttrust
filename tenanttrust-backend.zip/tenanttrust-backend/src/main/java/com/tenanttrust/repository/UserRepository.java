package com.tenanttrust.repository;

//import com.tenanttrust.model.Unit;

import com.tenanttrust.model.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface UserRepository extends JpaRepository<User, UUID>
{

    Optional<User> findByEmail(String email);
    Boolean existsByEmail(String email);

    Optional<User> findByIdAndRole(UUID id, User.UserRole role);

    Optional<User> findByRole(String role);

    long countByRole(String role);

    // Soft delete queries
    List<User> findByDeletedFalse();
    Optional<User> findByIdAndDeletedFalse(UUID id);

    // Use native query to bypass any interference
    @Query(value = "SELECT * FROM users WHERE id = ?1", nativeQuery = true)
    Optional<User> findByIdNative(UUID id);

    @Query(value = "SELECT * FROM users where deleted = 'FALSE'", nativeQuery = true)
    List<User> findAllUserActive();

    Optional<User> findByGoogleId(String googleId);

    List<User> findByProvider(String provider);

}