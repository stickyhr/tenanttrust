package com.tenanttrust.controller;

import com.tenanttrust.Exception.UserNotFoundException;
import com.tenanttrust.model.dto.PropertyResponseDTO;
import com.tenanttrust.model.dto.ReviewDTO;
import com.tenanttrust.model.dto.UserProfileDTO;
import com.tenanttrust.model.entities.User;
import com.tenanttrust.service.ProfileService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/profile")
@CrossOrigin(origins = "http://localhost:3000")
public class ProfileController
{
    @Autowired
    private ProfileService profileService;

    @GetMapping
    public ResponseEntity<UserProfileDTO.ProfileResponseDTO> getProfile(@AuthenticationPrincipal org.springframework.security.core.userdetails.User user)
    {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated())
        {
            return ResponseEntity.status(401).build();
        }
        UserProfileDTO.ProfileResponseDTO profile = profileService.getProfile(authentication.getName());
        return ResponseEntity.ok(profile);
    }

    @PutMapping
    public ResponseEntity<User> updateProfile(@AuthenticationPrincipal org.springframework.security.core.userdetails.User user,
            @Valid @RequestBody UserProfileDTO.UserProfileUpdateDTO updateDTO)
    {
        User updatedUser = profileService.updateProfile(user.getUsername(), updateDTO);
        return ResponseEntity.ok(updatedUser);
    }

    @GetMapping("/properties")
    public ResponseEntity<List<PropertyResponseDTO>> getMyProperties(@AuthenticationPrincipal User user)
    {
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        if (authentication == null || !authentication.isAuthenticated())
//        {
//            return ResponseEntity.status(401).build();
////        }
//        User usesr = userRepository.findById(userId)
//                .orElseThrow(() -> new UserNotFoundException("User not found"));
        List<PropertyResponseDTO> properties = profileService.getMyProperties(user.getEmail());
        return ResponseEntity.ok(properties);
    }

    @GetMapping("/reviews")
    public ResponseEntity<List<ReviewDTO.ReviewResponse>> getMyReviews(@AuthenticationPrincipal User user)
    {
        List<ReviewDTO.ReviewResponse> reviews = profileService.getMyReviews(user.getEmail());
        return ResponseEntity.ok(reviews);
    }

    @GetMapping("/stats")
    public ResponseEntity<UserProfileDTO.ProfileResponseStatsDTO> getProfileStats(
            @AuthenticationPrincipal User user)
    {
        UserProfileDTO.ProfileResponseDTO profile = profileService.getProfile(user.getEmail());
        return ResponseEntity.ok(profile.getStats());
    }
}