package com.tenanttrust.model.dto;

import com.tenanttrust.model.entities.User;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class UserProfileDTO
{
    public static class ProfileResponseDTO
    {
        public ProfileResponseDTO(User user, ProfileResponseStatsDTO stats, List<PropertyResponseDTO> myProperties,
                                  List<ReviewDTO.ReviewResponse> myReviews, LocalDateTime memberSince)
        {
            this.user = user;
            this.stats = stats;
            this.myProperties = myProperties;
            this.myReviews = myReviews;
            this.memberSince = memberSince;
        }

        public ProfileResponseDTO()
        {
        }

        private User user;
        private ProfileResponseStatsDTO stats;
        private List<PropertyResponseDTO> myProperties;
        private List<ReviewDTO.ReviewResponse> myReviews;
        private LocalDateTime memberSince;

        public User getUser()
        {
            return user;
        }

        public void setUser(User user)
        {
            this.user = user;
        }

        public ProfileResponseStatsDTO getStats()
        {
            return stats;
        }

        public void setStats(ProfileResponseStatsDTO stats)
        {
            this.stats = stats;
        }

        public List<PropertyResponseDTO> getMyProperties()
        {
            return myProperties;
        }

        public void setMyProperties(List<PropertyResponseDTO> myProperties)
        {
            this.myProperties = myProperties;
        }

        public List<ReviewDTO.ReviewResponse> getMyReviews()
        {
            return myReviews;
        }

        public void setMyReviews(List<ReviewDTO.ReviewResponse> myReviews)
        {
            this.myReviews = myReviews;
        }

        public LocalDateTime getMemberSince()
        {
            return memberSince;
        }

        public void setMemberSince(LocalDateTime memberSince)
        {
            this.memberSince = memberSince;
        }

    }


    public static class ProfileResponseStatsDTO
    {
        private int totalProperties;
        private int totalReviews;
        private double averageRatingGiven;

        private LocalDateTime lastActivity;

        public int getTotalProperties()
        {
            return totalProperties;
        }

        public void setTotalProperties(int totalProperties)
        {
            this.totalProperties = totalProperties;
        }

        public int getTotalReviews()
        {
            return totalReviews;
        }

        public void setTotalReviews(int totalReviews)
        {
            this.totalReviews = totalReviews;
        }

        public double getAverageRatingGiven()
        {
            return averageRatingGiven;
        }

        public void setAverageRatingGiven(double averageRatingGiven)
        {
            this.averageRatingGiven = averageRatingGiven;
        }

        public LocalDateTime getLastActivity()
        {
            return lastActivity;
        }

        public void setLastActivity(LocalDateTime lastActivity)
        {
            this.lastActivity = lastActivity;
        }

        public ProfileResponseStatsDTO(int totalProperties, int totalReviews, double averageRatingGiven, LocalDateTime lastActivity)
        {
            this.totalProperties = totalProperties;
            this.totalReviews = totalReviews;
            this.averageRatingGiven = averageRatingGiven;
            this.lastActivity = lastActivity;
        }

        public ProfileResponseStatsDTO()
        {
        }

    }


    public static class UserProfileUpdateDTO
    {
        private String fullName;

        private String phoneNumber;

        public String getFullName()
        {
            return fullName;
        }

        public void setFullName(String fullName)
        {
            this.fullName = fullName;
        }

        public String getPhoneNumber()
        {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber)
        {
            this.phoneNumber = phoneNumber;
        }

        public UserProfileUpdateDTO(String fullName, String phoneNumber)
        {
            this.fullName = fullName;
            this.phoneNumber = phoneNumber;
        }

    }
}
