package com.tenanttrust.service;

import com.tenanttrust.Exception.BadRequestException;
import com.tenanttrust.Exception.DuplicatePropertyException;
import com.tenanttrust.Exception.UserNotFoundException;
import com.tenanttrust.model.dto.PropertiesRequestDTO;
import com.tenanttrust.model.dto.PropertyResponseDTO;
import com.tenanttrust.model.entities.Property;
import com.tenanttrust.model.entities.User;
import com.tenanttrust.repository.PropertyRepository;
import com.tenanttrust.repository.ReviewRepository;
import com.tenanttrust.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class PropertyService
{
    private final PropertyRepository propertyRepository;
    private final UserRepository userRepository;
    private final ReviewRepository reviewRepository;

    //    @Override
    public Property getPropertyById(UUID propertyId)
    {
        return propertyRepository.findById(propertyId)
                .orElseThrow(() -> new RuntimeException("Property not found with id: " + propertyId));
    }

//    //    @Override
//    public List<Property> getPropertiesByCity(String city)
//    {
//        return propertyRepository.findByCityContainingIgnoreCase(city);
//    }

    //    @Override
    public List<Property> getTopRatedProperties(int limit)
    {
        return propertyRepository.findTopRatedProperties()
                .stream()
                .limit(limit)
                .collect(java.util.stream.Collectors.toList());
    }

    //    @Override
    public Page<Property> getAllProperties(Pageable pageable)
    {
        return propertyRepository.findAll(pageable);
    }

    public PropertyResponseDTO createProperty(PropertiesRequestDTO propertiesRequestDTO, UUID userId)
    {
        log.info("Creating property by user: {}", userId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found"));

//        if (!"ADMIN".equalsIgnoreCase(String.valueOf(user.getRole()))) // commentting condition to allow all users to create properties
//        {
//            throw new RuntimeException("Only administrators can create properties");
//        }

        // Check for duplicate property name
        boolean duplicateExists = propertyRepository.existsByPropertyNameAndCity(
                propertiesRequestDTO.getPropertyName(), propertiesRequestDTO.getCity());

        if (duplicateExists)
        {
            log.error("Duplicate property found: {} in {}", propertiesRequestDTO.getPropertyName(), propertiesRequestDTO.getCity());
            throw new DuplicatePropertyException("Property with this name already exists in the same city");
        }

        // Create new property
        Property property = new Property();
        property.setPropertyName(propertiesRequestDTO.getPropertyName());
        property.setDescription(propertiesRequestDTO.getDescription());
        property.setAddressLine1(propertiesRequestDTO.getAddressLine1());
        property.setAddressLine2(propertiesRequestDTO.getAddressLine2());
        property.setLocality(propertiesRequestDTO.getLocality());
        property.setCity(propertiesRequestDTO.getCity());
        property.setPincode(propertiesRequestDTO.getPincode());
        property.setLatitude(propertiesRequestDTO.getLatitude());
        property.setLongitude(propertiesRequestDTO.getLongitude());

        if (propertiesRequestDTO.getPropertyType() == null)
        {
            throw new BadRequestException("Property type must be one of APARTMENT, INDEPENDENT_HOUSE, VILLA, COMMERCIAL, PG_HOSTEL");
        }
        property.setPropertyType(propertiesRequestDTO.getPropertyType());

        // Set relationships and defaults
        property.setUserId(user); // The user is also the user associated with the property
        property.setCreatedBy(user);
        property.setIsVerified(false); // New properties are not verified by default
        property.setAggregatedRating(BigDecimal.valueOf(0.0));
        property.setReviewCount(0);
        property.setIsActive(true);
        property.setUserEmail(user.getEmail());
        property.setUserFullName(user.getFullName());

        Property savedProperty = propertyRepository.save(property);
        log.info("Property created successfully: {} - {}", savedProperty.getId(), savedProperty.getPropertyName());
        return new PropertyResponseDTO(savedProperty);
    }

    //    @Override
    public PropertyResponseDTO updateProperty(UUID propertyId, PropertiesRequestDTO propertiesRequestDTO, UUID userId)
    {
        Property property = getPropertyById(propertyId);

        property.setPropertyName(propertiesRequestDTO.getPropertyName());
        property.setDescription(propertiesRequestDTO.getDescription());
        property.setAddressLine1(propertiesRequestDTO.getAddressLine1());
        property.setAddressLine2(propertiesRequestDTO.getAddressLine2());
        property.setLocality(propertiesRequestDTO.getLocality());
        property.setCity(propertiesRequestDTO.getCity());
        property.setPincode(propertiesRequestDTO.getPincode());
        property.setLatitude(propertiesRequestDTO.getLatitude());
        property.setLongitude(propertiesRequestDTO.getLongitude());
        property.setPropertyType(propertiesRequestDTO.getPropertyType());

        Property savedProperty = propertyRepository.save(property);
        return new PropertyResponseDTO(savedProperty);
    }

    public boolean deactivateProperty(UUID propertyId, UUID admin)
    {
        boolean isPropertyDeactivated = false;
        Property property = propertyRepository.findById(propertyId)
                .orElseThrow(() -> new RuntimeException("Property not found with id: " + propertyId));

        isPropertyDeactivated = propertyRepository.isPropertyInActive(propertyId, true);
        if (isPropertyDeactivated)
        {
            property.setIsActive(false); // Soft delete by setting isActive to false
        }

        return isPropertyDeactivated;
    }


    public boolean reActivateProperty(UUID propertyId, UUID admin)
    {
        boolean isPropertyReactivated = false;
        Property property = propertyRepository.findById(propertyId)
                .orElseThrow(() -> new RuntimeException("Property not found with id: " + propertyId));

        isPropertyReactivated = propertyRepository.isPropertyInActive(propertyId, false);
        if (!isPropertyReactivated)
        {
            property.setIsActive(true); // Soft delete by setting isActive to false
        }

        return isPropertyReactivated;
    }

    public Property updateReviewCountAndAverageRating(UUID propertyId, int rating)
    {
        Property property = getPropertyById(propertyId);

        int oldCount = property.getReviewCount();
        BigDecimal oldAverage = property.getAggregatedRating();

        int newCount = oldCount + 1;
        BigDecimal totalRating = oldAverage.multiply(BigDecimal.valueOf(oldCount));
        totalRating = totalRating.add(BigDecimal.valueOf(rating));
        BigDecimal newAverage = totalRating.divide(BigDecimal.valueOf(newCount), 2, RoundingMode.HALF_UP);

        property.setReviewCount(newCount);
        property.setAggregatedRating(newAverage);
        return propertyRepository.save(property);
    }

    // NEW: Search methods
    public Page<PropertyResponseDTO> searchProperties(PropertiesRequestDTO searchRequest)
    {
        Pageable pageable = PageRequest.of(
                searchRequest.getPage(),
                searchRequest.getSize(),
                Sort.by(searchRequest.getSortDirection(), searchRequest.getSortBy())
        );

        Page<Property> properties = propertyRepository.searchProperties(
                searchRequest.getSearchCity(),
                searchRequest.getSearchPincode(),
                searchRequest.getSearchLocality(),
                searchRequest.getSearchPropertyType(),
                searchRequest.getSearchVerifiedOnly(),
                pageable
        );

        return properties.map(PropertyResponseDTO::new);
    }

    public List<PropertyResponseDTO> simpleSearch(String query)
    {
        Pageable pageable = PageRequest.of(0, 20); // Default pagination
        Page<Property> properties = propertyRepository.simpleSearch(query, pageable);
        return properties.getContent()
                .stream()
                .map(PropertyResponseDTO::new)
                .collect(Collectors.toList());
    }

    // Helper method for basic searches
    public List<PropertyResponseDTO> getPropertiesByCity(String city)
    {
        return propertyRepository.findByCityAndIsActiveTrue(city)
                .stream()
                .map(PropertyResponseDTO::new)
                .collect(Collectors.toList());
    }

    public List<PropertyResponseDTO> getPropertiesByPincode(String pincode)
    {
        return propertyRepository.findByPincodeAndIsActiveTrue(pincode)
                .stream()
                .map(PropertyResponseDTO::new)
                .collect(Collectors.toList());
    }
}