package com.tenanttrust.service;

import com.tenanttrust.model.entities.User;
import com.tenanttrust.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class GoogleAuthService
{
    @Autowired
    private UserRepository userRepository;

    public User processGoogleLogin(OAuth2AuthenticationToken authentication)
    {
        OAuth2User oauth2User = authentication.getPrincipal();

        String email = oauth2User.getAttribute("email");
        String name = oauth2User.getAttribute("name");
        String googleId = oauth2User.getAttribute("sub");

        // Check if user exists
        Optional<User> existingUser = userRepository.findByEmail(email);

        if (existingUser.isPresent())
        {
            // Update existing user if needed
            User user = existingUser.get();
            user.setLastLogin(LocalDateTime.now());
            return userRepository.save(user);
        } else
        {
            // Create new user
            User newUser = User.builder()
                    .email(email)
                    .fullName(name)
                    .googleId(googleId)
                    .role(User.UserRole.valueOf("TENANT")) // Default role
                    .enabled(true)
                    .createdAt(LocalDateTime.now())
                    .build();

            return userRepository.save(newUser);
        }
    }

}
