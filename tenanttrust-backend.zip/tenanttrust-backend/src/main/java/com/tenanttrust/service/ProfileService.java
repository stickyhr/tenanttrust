package com.tenanttrust.service;

import com.tenanttrust.Exception.ResourceNotFoundException;
import com.tenanttrust.model.dto.AuthResponseDTO;
import com.tenanttrust.model.dto.PropertyResponseDTO;
import com.tenanttrust.model.dto.ReviewDTO;
import com.tenanttrust.model.dto.UserProfileDTO;
import com.tenanttrust.model.entities.Property;
import com.tenanttrust.model.entities.Review;
import com.tenanttrust.model.entities.User;
import com.tenanttrust.repository.PropertyRepository;
import com.tenanttrust.repository.ReviewRepository;
import com.tenanttrust.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProfileService
{
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PropertyRepository propertyRepository;
    @Autowired
    private ReviewRepository reviewRepository;

    public UserProfileDTO.ProfileResponseDTO getProfile(String userEmail)
    {

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        // Get user's properties
        List<Property> userProperties = propertyRepository.getPropertiesByUserId(user.getId());

        if (userProperties == null)
        {
            throw new ResourceNotFoundException("No properties found for user");
        }
        // Get user's reviews
        List<Review> userReviews = reviewRepository.findByUserEmail(userEmail);

        // Build profile stats
        UserProfileDTO.ProfileResponseStatsDTO stats = buildProfileStats(userProperties, userReviews);

        // Convert to DTOs
        List<PropertyResponseDTO> propertyDTOs = userProperties.stream()
                .map(this::convertToPropertyDTO)
                .collect(Collectors.toList());

        List<ReviewDTO.ReviewResponse> reviewDTOs = userReviews.stream()
                .map(this::convertToReviewDTO)
                .collect(Collectors.toList());

        UserProfileDTO.ProfileResponseDTO profile = new UserProfileDTO.ProfileResponseDTO();
        profile.setUser(AuthResponseDTO.fromUser(user));
        profile.setStats(stats);
        profile.setMyProperties(propertyDTOs);
        profile.setMyReviews(reviewDTOs);
        profile.setMemberSince(user.getCreatedAt());

        return profile;
    }

    public User updateProfile(String userEmail, UserProfileDTO.UserProfileUpdateDTO updateDTO)
    {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        // Update allowed fields
        if (updateDTO.getFullName() != null)
        {
            user.setFullName(updateDTO.getFullName());
        }
        if (updateDTO.getPhoneNumber() != null)
        {
            user.setPhoneNumber(updateDTO.getPhoneNumber());
        }
        user.setUpdatedAt(LocalDateTime.now());
        User updatedUser = userRepository.save(user);
        return AuthResponseDTO.fromUser(updatedUser);
    }

    public List<PropertyResponseDTO> getMyProperties(String userEmail)
    {
        User u_email = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        List<Property> properties = propertyRepository.getPropertiesByUserId(u_email.getId());
        return properties.stream()
                .map(this::convertToPropertyDTO)
                .collect(Collectors.toList());
    }

    public List<ReviewDTO.ReviewResponse> getMyReviews(String userEmail)
    {
        List<Review> reviews = reviewRepository.findByUserEmail(userEmail);
        return reviews.stream()
                .map(this::convertToReviewDTO)
                .collect(Collectors.toList());
    }

    private UserProfileDTO.ProfileResponseStatsDTO buildProfileStats(List<Property> properties, List<Review> reviews)
    {
        UserProfileDTO.ProfileResponseStatsDTO stats = new UserProfileDTO.ProfileResponseStatsDTO();
        stats.setTotalProperties(properties.size());
        stats.setTotalReviews(reviews.size());

        // Calculate average rating given by user
        double avgRating = reviews.stream()
                .mapToInt(Review::getRating)
                .average()
                .orElse(0.0);
        stats.setAverageRatingGiven(Math.round(avgRating * 10.0) / 10.0);

        // Find last activity (latest property created or review submitted)
        LocalDateTime lastPropertyActivity = properties.stream()
                .map(Property::getCreatedAt)
                .max(LocalDateTime::compareTo)
                .orElse(null);

        LocalDateTime lastReviewActivity = reviews.stream()
                .map(Review::getCreatedAt)
                .max(LocalDateTime::compareTo)
                .orElse(null);

        LocalDateTime lastActivity = lastPropertyActivity;
        if (lastReviewActivity != null &&
                (lastActivity == null || lastReviewActivity.isAfter(lastActivity)))
        {
            lastActivity = lastReviewActivity;
        }

        stats.setLastActivity(lastActivity);

        return stats;
    }

    private PropertyResponseDTO convertToPropertyDTO(Property property)
    {
        PropertyResponseDTO dto = new PropertyResponseDTO();
        dto.setId(property.getId());
        dto.setDescription(property.getDescription());
        dto.setAddressLine1(property.getAddressLine1());
        dto.setAddressLine2(property.getAddressLine2());
        dto.setCity(property.getCity());
        dto.setPincode(property.getPincode());
        dto.setLocality(property.getLocality());
        dto.setPropertyName(property.getPropertyName());
        dto.setCity(property.getCity());
        dto.setPropertyType(property.getPropertyType());
        dto.setCreatedAt(property.getCreatedAt());
        return dto;
    }

    private ReviewDTO.ReviewResponse convertToReviewDTO(Review review)
    {
        ReviewDTO.ReviewResponse dto = new ReviewDTO.ReviewResponse();
        dto.setId(review.getId());
        dto.setPropertyId(review.getProperty().getId());
        dto.setRating(review.getRating());
        dto.setMaintenance(review.getMaintenance());
        dto.setCommunication(review.getCommunication());
        dto.setValue(review.getValue());
        dto.setPros(review.getPros());
        dto.setCons(review.getCons());
        dto.setTenureStart(review.getTenureStart());
        dto.setTenureEnd(review.getTenureEnd());
        dto.setReviewScope(review.getReviewScope());
        dto.setCreatedAt(String.valueOf(review.getCreatedAt()));
        dto.setUpdatedAt(String.valueOf(review.getUpdatedAt()));
        return dto;
    }
}
