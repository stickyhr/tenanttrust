package com.tenanttrust.repository;

import com.tenanttrust.model.entities.Review;
import com.tenanttrust.model.entities.Review.ReviewStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.awt.print.Pageable;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface ReviewRepository extends JpaRepository<Review, UUID>
{
    List<Review> findByPropertyIdAndReviewStatus(UUID propertyId, ReviewStatus review_status);

//    List<Review> findByReviewStatus(ReviewStatus status);
//
//    List<Review> findByPropertyId(UUID propertyId);

//    @Query("SELECT AVG(r.rating) FROM Review r WHERE r.property.id = :propertyId AND r.status = 'APPROVED'")
//    Double findAverageRatingByPropertyId(@Param("propertyId") UUID propertyId);


    // FIXED: Use proper query syntax and return Optional<Double>
    @Query("SELECT AVG(r.rating) FROM Review r WHERE r.property.id = :propertyId")
    Optional<Double> findAverageRatingByPropertyId(@Param("propertyId") UUID propertyId);

//    @Query("SELECT COUNT(r) FROM Review r WHERE r.property.id = :property_id AND r.review_status = 'APPROVED'")
//    Integer countApprovedReviewsByPropertyId(@Param("property_id") UUID property_id);
//

    // Fixed query - changed review_status to reviewStatus
    @Query("SELECT COUNT(r) FROM Review r WHERE r.property.id = :propertyId AND r.reviewStatus = 'APPROVED'")
    Integer countApprovedReviewsByPropertyId(@Param("propertyId") UUID propertyId);


    @Query("SELECT CASE WHEN COUNT(r) > 0 THEN TRUE ELSE FALSE END FROM Review r WHERE r.property.id = :propertyId AND r.user.id = :userId")
    boolean existsByPropertyIdAndUserId(@Param("propertyId") UUID propertyId, @Param("userId") UUID userId);


    @Query("SELECT r FROM Review r WHERE r.user.id = :userId ORDER BY r.createdAt DESC")
    List<Review> findByUserId(@Param("userId") UUID userId);

    @Query("SELECT r FROM Review r ORDER BY r.createdAt DESC")
    List<Review> findRecentReviews(Pageable pageable);

    List<Review> findByPropertyIdOrderByCreatedAtDesc(UUID propertyId);

    Optional<Review> findByPropertyIdAndUserId(UUID propertyId, UUID userId);

//    boolean existsByPropertyIdAndUserId(Long propertyId, Long userId);

    // Custom query to get average ratings for all categories
    @Query("SELECT " +
            "AVG(r.rating), AVG(r.maintenance), AVG(r.communication), AVG(r.value) " +
            "FROM Review r WHERE r.property.id = :propertyId")
    Object[] findAverageRatingsByPropertyId(@Param("propertyId") Long propertyId);

    List<Review> findByUserIdOrderByCreatedAtDesc(UUID userId);

    Optional<Review> findById(UUID reviewId);

    Optional<Review> findByEmail(String email);

//    Optional<Review> isReviewStatusApproved(UUID propertyId);

//    // NEW: Find reviews by property ID
//    List<Review> findByPropertyIdAndIsActiveTrue(UUID propertyId);
//
//    // Find reviews by property ID with pagination
//    Page<Review> findByPropertyIdAndIsActiveTrue(UUID propertyId, Pageable pageable);
//
//    // Find recent reviews by property ID (for preview)
//    List<Review> findTop3ByPropertyIdAndIsActiveTrueOrderByCreatedAtDesc(UUID propertyId);
//
//    // Count reviews for a property
//    @Query("SELECT COUNT(r) FROM Review r WHERE r.property.id = :propertyId AND r.isActive = true")
//    Long countByPropertyId(@Param("propertyId") UUID propertyId);

    List<Review> findByUserEmail(String userEmail);

    long countByUserEmail(String userEmail);

    long countByUserEmailAndReviewStatus(String userEmail, Review.ReviewStatus status);
}