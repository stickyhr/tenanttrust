package com.tenanttrust.controller;

import com.tenanttrust.model.entities.User;
import com.tenanttrust.model.dto.AuthRequestDTO;
import com.tenanttrust.repository.UserRepository;
import com.tenanttrust.config.JwtService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testRegisterUser() throws Exception {
        AuthRequestDTO authRequestDTO = new AuthRequestDTO();
        authRequestDTO.setEmail("test@example.com");
        authRequestDTO.setPassword("password123");

        mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(authRequestDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").exists())
                .andExpect(jsonPath("$.user.email").value("test@example.com"));
    }

    @Test
    void testLoginUser() throws Exception {
        // First create a user
        User user = new User();
        user.setEmail("login_test@example.com");
        user.setPassword(passwordEncoder.encode("password123"));
        user.setFullName("Test User");
        user.setRole(User.UserRole.TENANT);
        userRepository.save(user);

        AuthRequestDTO authRequestDTO = new AuthRequestDTO();
        authRequestDTO.setEmail("login_test@example.com");
        authRequestDTO.setPassword("password123");

        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(authRequestDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").exists())
                .andExpect(jsonPath("$.user.email").value("login_test@example.com"));
    }

    @Test
    void testGetCurrentUser() throws Exception {
        // Create a user and generate token
        User user = new User();
        user.setEmail("current_user@example.com");
        user.setPassword(passwordEncoder.encode("password123"));
        user.setFullName("Current User");
        user.setRole(User.UserRole.TENANT);
        userRepository.save(user);

        String token = jwtService.generateToken(user);

        mockMvc.perform(get("/api/auth/me")
                        .header("Authorization", "Bearer" + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("current_user@example.com"));
    }
}