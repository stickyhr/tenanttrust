package com.tenanttrust.model.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "reviews")
@Getter
@Setter
public class Review
{

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "property_id", nullable = false)
    private Property property;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @NotNull
    private String email;

    private String fullName;

    @Min(1)
    @Max(5)
    @Column(nullable = false)
    private Integer rating;

    @Min(1)
    @Max(5)
    private Integer maintenance;

    @Min(1)
    @Max(5)
    private Integer communication;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;
    @Min(1)
    @Max(5)
    private Integer value;

    @Size(min = 10, max = 500)
    private String pros;

    @Size(min = 10, max = 500)
    private String cons;

    private LocalDate tenureStart;
    private LocalDate tenureEnd;

    @Enumerated(EnumType.STRING)
    private ReviewStatus reviewStatus = ReviewStatus.APPROVED;

    @Enumerated(EnumType.STRING)
    private ReviewScope reviewScope = ReviewScope.FORMER_TENANT;

    public String getEmail()
    {
        return email;
    }

    @Builder.Default
    private Boolean isAnonymous = true; // Always true for TT platform

    public void setEmail(String email)
    {
        this.email = email;
    }

    public Review()
    {

    }

    public Review(Property property, User user, String email, String fullName, Integer rating,
                  Integer maintenance, Integer communication, LocalDateTime createdAt,
                  LocalDateTime updatedAt, Integer value, String pros, String cons, LocalDate tenureStart,
                  LocalDate tenureEnd, ReviewScope reviewScope)
    { //d
//        this.id = id;
        this.property = property;
        this.user = user;
        this.email = email;
        this.fullName = fullName;
        this.rating = rating;
        this.maintenance = maintenance;
        this.communication = communication;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.value = value;
        this.pros = pros;
        this.cons = cons;
        this.tenureStart = tenureStart;
        this.tenureEnd = tenureEnd;
//        this.reviewStatus = reviewStatus;
        this.reviewScope = reviewScope;
    }

    public enum ReviewStatus
    {
        PENDING, APPROVED, REJECTED
    }

    public enum ReviewScope
    {
        RENTED, VISITED, OWNED, FORMER_TENANT
    }

    public ReviewScope getReviewScope()
    {
        return reviewScope;
    }

    public void setReviewScope(ReviewScope reviewScope)
    {
        this.reviewScope = reviewScope;
    }

    public UUID getId()
    {
        return id;
    }

    public void setId(UUID id)
    {
        this.id = id;
    }

    public Property getProperty()
    {
        return property;
    }

    public void setProperty(Property property)
    {
        this.property = property;
    }

    public User getUser()
    {
        return user;
    }

    public void setUser(User user)
    {
        this.user = user;
    }

    public String getUserFullName()
    {
        return fullName;
    }

    public void setUserFullName(String fullName)
    {
        this.fullName = fullName;
    }

    public Integer getRating()
    {
        return rating;
    }

    public void setRating(Integer rating)
    {
        this.rating = rating;
    }

    public Integer getMaintenance()
    {
        return maintenance;
    }

    public void setMaintenance(Integer maintenance)
    {
        this.maintenance = maintenance;
    }

    public Integer getCommunication()
    {
        return communication;
    }

    public void setCommunication(Integer communication)
    {
        this.communication = communication;
    }

    public Integer getValue()
    {
        return value;
    }

    public void setValue(Integer value)
    {
        this.value = value;
    }

    public String getPros()
    {
        return pros;
    }

    public void setPros(String pros)
    {
        this.pros = pros;
    }

    public String getCons()
    {
        return cons;
    }

    public void setCons(String cons)
    {
        this.cons = cons;
    }

    public LocalDate getTenureStart()
    {
        return tenureStart;
    }

    public void setTenureStart(LocalDate tenureStart)
    {
        this.tenureStart = tenureStart;
    }

    public LocalDate getTenureEnd()
    {
        return tenureEnd;
    }

    public void setTenureEnd(LocalDate tenureEnd)
    {
        this.tenureEnd = tenureEnd;
    }

    public ReviewStatus getReviewStatus()
    {
        return reviewStatus;
    }

    public void setReviewStatus(ReviewStatus reviewStatus)
    {
        this.reviewStatus = reviewStatus;
    }

    public LocalDateTime getCreatedAt()
    {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt)
    {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt()
    {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt)
    {
        this.updatedAt = updatedAt;
    }

    @PrePersist
    protected void onCreate()
    {
        if (createdAt == null)
        {
            createdAt = LocalDateTime.now();
        }
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate()
    {
        updatedAt = LocalDateTime.now();
    }

    // Helper method to get anonymous display name
    public String getAnonymousDisplayName()
    {
        return "Anonymous Tenant";
    }
}