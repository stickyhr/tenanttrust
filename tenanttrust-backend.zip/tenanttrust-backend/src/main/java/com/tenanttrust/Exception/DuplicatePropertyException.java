package com.tenanttrust.Exception;

public class DuplicatePropertyException extends RuntimeException
{
public DuplicatePropertyException(String message)
    {
        super(message);
    }
}
