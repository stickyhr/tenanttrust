package com.tenanttrust.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/version")
public class VersionController
{

    @Value("${app.info.version:name}")
    private String appVersion;

    @Value("${spring.profiles.active:development}")
    private String environment;

    @GetMapping
    public Map<String, String> getVersion()
    {
        Map<String, String> response = new HashMap<>();
        response.put("version", appVersion);
        response.put("name", "TenantTrust API");
        response.put("environment", environment);
        response.put("status", "OK");
        return response;
    }
}