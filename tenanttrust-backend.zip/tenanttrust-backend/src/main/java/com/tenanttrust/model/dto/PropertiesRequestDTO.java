package com.tenanttrust.model.dto;

import com.tenanttrust.model.entities.Property;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import org.springframework.data.domain.Sort;

import java.math.BigDecimal;
import java.util.UUID;

public class PropertiesRequestDTO
{
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @NotBlank(message = "Property name is required")
    private String propertyName;

    private String description;

    @NotBlank
    @NotBlank(message = "Address1 is required")
    private String addressLine1;

    @NotBlank
    @NotBlank(message = "Address2 is required")
    private String addressLine2;

    @NotBlank(message = "Locality is required")
    private String locality;

    @NotBlank
    private String city;

    @NotBlank
    @Pattern(regexp = "\\d{6}", message = "Pincode must be 6 digits")
    private String pincode;

    private BigDecimal latitude;
    private BigDecimal longitude;

    @Enumerated(EnumType.STRING)
    @NotNull(message = "Property type is required")
    private Property.PropertyType propertyType;

    public PropertiesRequestDTO()
    {

    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    private Boolean isVerified = false;
    private BigDecimal aggregatedRating = BigDecimal.ZERO;
    private Integer reviewCount = 0;

    // search property

    // NEW: Search-specific fields
    private String searchCity;
    private String searchPincode;
    private String searchLocality;
    private Property.PropertyType searchPropertyType;
    private Boolean searchVerifiedOnly;
    private Integer page = 0;
    private Integer size = 20;
    private String sortBy = "createdAt";
    private Sort.Direction sortDirection = Sort.Direction.DESC;

    // Helper method to check if this is a search request
    public boolean isSearchRequest()
    {
        return searchCity != null || searchPincode != null ||
                searchLocality != null || searchPropertyType != null ||
                searchVerifiedOnly != null;
    }

    //


//    public PropertiesRequestDTO(UUID id, String propertyName, String description, String addressLine1, String addressLine2, String locality,
//                                String city, String pincode, BigDecimal latitude, BigDecimal longitude,
//                                Property.PropertyType propertyType, Boolean isVerified,
//                                BigDecimal aggregatedRating, Integer reviewCount)
//    {
//        this.id = id;
//        this.propertyName = propertyName;
//        this.description = description;
//        this.addressLine1 = addressLine1;
//        this.addressLine2 = addressLine2;
//        this.locality = locality;
//        this.city = city;
//        this.pincode = pincode;
//        this.latitude = latitude;
//        this.longitude = longitude;
//        this.propertyType = propertyType;
//        this.isVerified = isVerified;
//        this.aggregatedRating = aggregatedRating;
//        this.reviewCount = reviewCount;
//    }


    public String getSearchCity()
    {
        return searchCity;
    }

    public void setSearchCity(String searchCity)
    {
        this.searchCity = searchCity;
    }

    public String getSearchPincode()
    {
        return searchPincode;
    }

    public void setSearchPincode(String searchPincode)
    {
        this.searchPincode = searchPincode;
    }

    public String getSearchLocality()
    {
        return searchLocality;
    }

    public void setSearchLocality(String searchLocality)
    {
        this.searchLocality = searchLocality;
    }

    public Property.PropertyType getSearchPropertyType()
    {
        return searchPropertyType;
    }

    public void setSearchPropertyType(Property.PropertyType searchPropertyType)
    {
        this.searchPropertyType = searchPropertyType;
    }

    public Boolean getSearchVerifiedOnly()
    {
        return searchVerifiedOnly;
    }

    public void setSearchVerifiedOnly(Boolean searchVerifiedOnly)
    {
        this.searchVerifiedOnly = searchVerifiedOnly;
    }

    public Integer getPage()
    {
        return page;
    }

    public void setPage(Integer page)
    {
        this.page = page;
    }

    public Integer getSize()
    {
        return size;
    }

    public void setSize(Integer size)
    {
        this.size = size;
    }

    public String getSortBy()
    {
        return sortBy;
    }

    public void setSortBy(String sortBy)
    {
        this.sortBy = sortBy;
    }

    public Sort.Direction getSortDirection()
    {
        return sortDirection;
    }

    public void setSortDirection(Sort.Direction sortDirection)
    {
        this.sortDirection = sortDirection;
    }

    public PropertiesRequestDTO(UUID id, String propertyName, String description, String addressLine1, String addressLine2, String locality, String city, String pincode, BigDecimal latitude, BigDecimal longitude, Property.PropertyType propertyType, Boolean isVerified, BigDecimal aggregatedRating, Integer reviewCount, String searchCity, String searchPincode, String searchLocality, Property.PropertyType searchPropertyType, Boolean searchVerifiedOnly, Integer page, Integer size, String sortBy, Sort.Direction sortDirection)
    {
        this.id = id;
        this.propertyName = propertyName;
        this.description = description;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.locality = locality;
        this.city = city;
        this.pincode = pincode;
        this.latitude = latitude;
        this.longitude = longitude;
        this.propertyType = propertyType;
        this.isVerified = isVerified;
        this.aggregatedRating = aggregatedRating;
        this.reviewCount = reviewCount;
        this.searchCity = searchCity;
        this.searchPincode = searchPincode;
        this.searchLocality = searchLocality;
        this.searchPropertyType = searchPropertyType;
        this.searchVerifiedOnly = searchVerifiedOnly;
        this.page = page;
        this.size = size;
        this.sortBy = sortBy;
        this.sortDirection = sortDirection;
    }

    public UUID getId()
    {
        return id;
    }

    public void setId(UUID id)
    {
        this.id = id;
    }

    public String getPropertyName()
    {
        return propertyName;
    }

    public void setPropertyName(String propertyName)
    {
        this.propertyName = propertyName;
    }

    public String getAddressLine1()
    {
        return addressLine1;
    }

    public void setAddressLine1(String addressline1)
    {
        this.addressLine1 = addressline1;
    }

    public String getAddressLine2()
    {
        return addressLine2;
    }

    public void setAddressLine2(String addressline2)
    {
        this.addressLine2 = addressline2;
    }

    public String getLocality()
    {
        return locality;
    }

    public void setLocality(String locality)
    {
        this.locality = locality;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getPincode()
    {
        return pincode;
    }

    public void setPincode(String pincode)
    {
        this.pincode = pincode;
    }

    public BigDecimal getLatitude()
    {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude)
    {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude()
    {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude)
    {
        this.longitude = longitude;
    }

    public Property.PropertyType getPropertyType()
    {
        return propertyType;
    }

    public void setPropertyType(Property.PropertyType propertyType)
    {
        this.propertyType = propertyType;
    }

    public Boolean getVerified()
    {
        return isVerified;
    }

    public void setVerified(Boolean verified)
    {
        isVerified = verified;
    }

    public BigDecimal getAggregatedRating()
    {
        return aggregatedRating;
    }

    public void setAggregatedRating(BigDecimal aggregatedRating)
    {
        this.aggregatedRating = aggregatedRating;
    }

    public Integer getReviewCount()
    {
        return reviewCount;
    }

    public void setReviewCount(Integer reviewCount)
    {
        this.reviewCount = reviewCount;
    }

}
