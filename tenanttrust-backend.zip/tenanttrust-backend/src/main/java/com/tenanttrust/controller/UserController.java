package com.tenanttrust.controller;

import com.tenanttrust.model.dto.ApiResponse;
import com.tenanttrust.model.entities.User;
import com.tenanttrust.repository.UserRepository;
import com.tenanttrust.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class UserController
{
    private final UserRepository userRepository;
    private final UserService userService;

//    // Manual constructor injection
//    @Autowired
//    public AdminController(UserRepository userRepository)
//    {
//        this.userRepository = userRepository;
//    }

    @GetMapping("/users")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<User>> getAllUsers()
    {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated())
        {
            return ResponseEntity.status(401).build();
        }
        List<User> user = userRepository.findAllUserActive();
        return ResponseEntity.ok(user);
    }

    @DeleteMapping("/delete/user/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse> deleteUsers(@PathVariable UUID id)
    {
        userService.deleteUser(id);
        return ResponseEntity.ok(
                new ApiResponse(true, "User deleted successfully")
        );
    }

    @PutMapping("/update/user/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse> updateUserRole(@PathVariable UUID id, @RequestParam String role)
    {
        userService.updateUserRole(id, role);
        return ResponseEntity.ok(
                new ApiResponse(true, "User role updated successfully")
        );
    }

    @PutMapping("/updateProfile/{id}") // updating user profile with full name and phone number only as of now
    public ResponseEntity<ApiResponse> updateUserProfile(@PathVariable UUID id, @RequestBody User updatedUser)
    {
        userService.updateUserProfile(id, updatedUser);
        return ResponseEntity.ok(new ApiResponse(true, "User profile updated successfully"));
    }

    @PutMapping("/changePassword/{id}") // changing user password
    public ResponseEntity<ApiResponse> changeUserPassword(@PathVariable UUID id, @RequestParam String newPassword)
    {
        userService.changeUserPassword(id, newPassword);
        return ResponseEntity.ok(new ApiResponse(true, "User password changed successfully"));
    }



}