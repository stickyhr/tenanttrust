package com.tenanttrust;

public class TenantTrustApplicationTests
{
}
