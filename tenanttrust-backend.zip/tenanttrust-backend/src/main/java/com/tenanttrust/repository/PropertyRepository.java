package com.tenanttrust.repository;

import com.tenanttrust.model.entities.Property;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface PropertyRepository extends JpaRepository<Property, UUID>
{
    @Query("SELECT p FROM Property p WHERE LOWER(p.locality) LIKE LOWER(CONCAT('%', :locality, '%')) AND LOWER(p.city) LIKE LOWER(CONCAT('%', :city, '%'))")
    List<Property> findByCityContainingIgnoreCase(String city);

    List<Property> findByCityAndIsActive(String city, Boolean is_active);

    Optional<Property> findById(UUID id);

    @Query("SELECT p FROM Property p ORDER BY p.aggregatedRating DESC NULLS LAST")
    List<Property> findTopRatedProperties();

    boolean existsByPropertyNameAndCity(String property_name, String city);

    @Query(value = "SELECT * FROM properties where is_active = 'TRUE'", nativeQuery = true)
    List<Property> findAllProperties();

    @Query("SELECT CASE WHEN COUNT(p) > 0 THEN TRUE ELSE FALSE END FROM Property p WHERE p.id = :Id AND p.isActive = :is_active")
    boolean isPropertyInActive(UUID Id, Boolean is_active);

    List<Property> findByCityAndIsActiveTrue(String city);

    List<Property> findByPincodeAndIsActiveTrue(String pincode);

    // Combined search with pagination
    @Query("SELECT p FROM Property p WHERE " +
            "(:city IS NULL OR p.city ILIKE %:city%) AND " +
            "(:pincode IS NULL OR p.pincode = :pincode) AND " +
            "(:locality IS NULL OR p.locality ILIKE %:locality%) AND " +
            "(:propertyType IS NULL OR p.propertyType = :propertyType) AND " +
            "(:verifiedOnly IS NULL OR p.isVerified = :verifiedOnly) AND " +
            "p.isActive = true")
    Page<Property> searchProperties(
            @Param("city") String city,
            @Param("pincode") String pincode,
            @Param("locality") String locality,
            @Param("propertyType") Property.PropertyType propertyType,
            @Param("verifiedOnly") Boolean verifiedOnly,
            Pageable pageable);

    // Simple search across multiple fields
    @Query("SELECT p FROM Property p WHERE " +
            "(p.city ILIKE %:query% OR p.locality ILIKE %:query% OR p.propertyName ILIKE %:query%) AND " +
            "p.isActive = true")
    Page<Property> simpleSearch(@Param("query") String query, Pageable pageable);

    @Query("SELECT p FROM Property p WHERE p.userId.id = :userId")
    List<Property> getPropertiesByUserId(UUID userId);
}