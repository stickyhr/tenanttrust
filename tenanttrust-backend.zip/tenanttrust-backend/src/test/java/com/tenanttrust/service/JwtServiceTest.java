package com.tenanttrust.service;

import com.tenanttrust.config.JwtService;
import com.tenanttrust.model.entities.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class JwtServiceTest {

    @Autowired
    private JwtService jwtService;

    @Test
    void testTokenGenerationAndValidation() {
        // Create a test user
        User user = new User();
        user.setEmail("test@example.com");
        user.setPassword("password");

        // Generate token
        String token = jwtService.generateToken(user);

        // Verify token format
        assertNotNull(token);
        assertTrue(token.split("\\.").length == 3, "Token should have 3 parts");
        assertFalse(token.contains(" "), "Token should not contain spaces");

        // Verify token can be parsed
        String username = jwtService.extractUsername(token);
        assertEquals("test@example.com", username);

        // Verify token validation
        assertTrue(jwtService.validateToken(token, user));
    }
}