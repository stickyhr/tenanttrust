package com.tenanttrust.service;

import com.tenanttrust.Exception.ResourceNotFoundException;
import com.tenanttrust.Exception.ReviewAlreadyGivenException;
import com.tenanttrust.model.dto.ReviewDTO;
//import com.tenanttrust.model.dto.ReviewResponseDTO;
import com.tenanttrust.model.entities.Property;
import com.tenanttrust.model.entities.Review;
import com.tenanttrust.model.entities.User;
import com.tenanttrust.repository.PropertyRepository;
import com.tenanttrust.repository.ReviewRepository;
import com.tenanttrust.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReviewService
{
    @Autowired
    private final ReviewRepository reviewRepository;
    @Autowired
    private final PropertyRepository propertyRepository;
    @Autowired
    private final PropertyService propertyService;
    @Autowired
    private final UserRepository userRepository;

    @Transactional
    public ReviewDTO.ReviewResponse createReview(ReviewDTO.CreateReviewRequest reviewRequestDTO, String userEmail)
    {
        // Get current user
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        boolean propertyExists = propertyRepository.existsById(reviewRequestDTO.getPropertyId());
        System.out.println("Property exists in DB: " + propertyExists);

        // Get property with proper Optional handling
        Property property = propertyRepository.findById(reviewRequestDTO.getPropertyId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Property not found with ID: " + reviewRequestDTO.getPropertyId() +
                                ". Available properties: " + getAllPropertyIds()));

        // Check if user already reviewed this property
        if (reviewRepository.existsByPropertyIdAndUserId(property.getId(), user.getId()))
        {
            System.out.println("You have already reviewed this property");
            throw new ReviewAlreadyGivenException("You have already reviewed this property");
        }

        Review review = new Review();
        review.setProperty(property);
        review.setUser(user);
        review.setEmail(user.getEmail());
        review.setFullName(user.getFullName()); // Set username
        review.setRating(reviewRequestDTO.getRating());
        review.setMaintenance(reviewRequestDTO.getMaintenance());
        review.setCommunication(reviewRequestDTO.getCommunication());
        review.setValue(reviewRequestDTO.getValue());
        review.setPros(reviewRequestDTO.getPros());
        review.setCons(reviewRequestDTO.getCons());
        review.setTenureStart(reviewRequestDTO.getTenureStart());
        review.setTenureEnd(reviewRequestDTO.getTenureEnd());
        review.setReviewScope(reviewRequestDTO.getReviewScope());
        review.setReviewStatus(Review.ReviewStatus.APPROVED);

        Review savedReview = reviewRepository.save(review);

        if (savedReview.getId() != null)
        {
            propertyService.updateReviewCountAndAverageRating(property.getId(), savedReview.getRating());
        }
        else
            throw new RuntimeException("Failed to save review");

        return convertToReviewResponse(savedReview);
    }

    public List<ReviewDTO.ReviewResponse> getReviewsByPropertyId(UUID propertyId)
    {
        return reviewRepository.findByPropertyIdAndReviewStatus(propertyId, Review.ReviewStatus.APPROVED)
                .stream()
                .map(this::convertToReviewResponse)
                .collect(Collectors.toList());
    }

    public boolean hasUserReviewedProperty(UUID propertyId, UUID userId)
    {
        return reviewRepository.existsByPropertyIdAndUserId(propertyId, userId);
    }

    @Transactional
    public void updatePropertyAggregatedRating(UUID propertyId)
    {
        Optional<Double> averageRating = reviewRepository.findAverageRatingByPropertyId(propertyId);
        Integer reviewCount = reviewRepository.countApprovedReviewsByPropertyId(propertyId);

        Property property = propertyRepository.findById(propertyId)
                .orElseThrow(() -> new RuntimeException("Property not found"));

        property.setAggregatedRating(BigDecimal.valueOf((Long) (averageRating != null ? averageRating : 0.0)));
        property.setReviewCount(reviewCount);
        propertyRepository.save(property);
    }

    public ReviewDTO.PropertyReviewsResponse getPropertyReviews(UUID propertyId)
    {
        // Verify property exists
        if (!propertyRepository.existsById(propertyId))
        {
            throw new ResourceNotFoundException("Property not found");
        }

        List<Review> reviews = reviewRepository.findByPropertyIdOrderByCreatedAtDesc(propertyId);

        // Calculate averages
        Double averageRating = calculateAverage(reviews.stream().map(Review::getRating).collect(Collectors.toList()));
        Double averageMaintenance = calculateAverage(reviews.stream().map(Review::getMaintenance).collect(Collectors.toList()));
        Double averageCommunication = calculateAverage(reviews.stream().map(Review::getCommunication).collect(Collectors.toList()));
        Double averageValue = calculateAverage(reviews.stream().map(Review::getValue).collect(Collectors.toList()));

        List<ReviewDTO.ReviewResponse> reviewResponses = reviews.stream()
                .map(this::convertToReviewResponse)
                .collect(Collectors.toList());

        ReviewDTO.PropertyReviewsResponse response = new ReviewDTO.PropertyReviewsResponse();
        response.setAverageRating(roundToDecimal(averageRating));
        response.setAverageMaintenance(roundToDecimal(averageMaintenance));
        response.setAverageCommunication(roundToDecimal(averageCommunication));
        response.setAverageValue(roundToDecimal(averageValue));
        response.setTotalReviews(reviews.size());
        response.setReviews(reviewResponses);

        return response;
    }

    @Transactional
    public ReviewDTO.ReviewResponse updateReview(UUID reviewId, ReviewDTO.CreateReviewRequest request, String userEmail)
    {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new ResourceNotFoundException("Review not found"));

        // Check if user owns the review
        User user = reviewRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found")).getUser();

        if (!review.getUser().getId().equals(user.getId()))
        {
            throw new SecurityException("You can only update your own reviews");
        }

        // Update all fields
        review.setRating(request.getRating());
        review.setMaintenance(request.getMaintenance());
        review.setCommunication(request.getCommunication());
        review.setValue(request.getValue());
        review.setPros(request.getPros());
        review.setCons(request.getCons());
        review.setTenureStart(request.getTenureStart());
        review.setTenureEnd(request.getTenureEnd());
        review.setReviewScope(request.getReviewScope());

        Review updatedReview = reviewRepository.save(review);

        return convertToReviewResponse(updatedReview);
    }

    // Helper method to calculate average
    private Double calculateAverage(List<Integer> values)
    {
        if (values == null || values.isEmpty())
        {
            return 0.0;
        }
        return values.stream().mapToInt(Integer::intValue).average().orElse(0.0);
    }

    // Helper method to round to 1 decimal place
    private Double roundToDecimal(Double value)
    {
        return Math.round(value * 10.0) / 10.0;
    }

    private ReviewDTO.ReviewResponse convertToReviewResponse(Review review)
    {
        ReviewDTO.ReviewResponse response = new ReviewDTO.ReviewResponse();
        response.setId(review.getId());
        response.setPropertyId(review.getProperty().getId());
        response.setUserEmail(review.getUser().getEmail());
        response.setUserName(review.getUserFullName());
        response.setRating(review.getRating());
        response.setMaintenance(review.getMaintenance());
        response.setCommunication(review.getCommunication());
        response.setValue(review.getValue());
        response.setPros(review.getPros());
        response.setCons(review.getCons());
        response.setTenureStart(review.getTenureStart());
        response.setTenureEnd(review.getTenureEnd());
        response.setReviewScope(review.getReviewScope());
        response.setCreatedAt(review.getCreatedAt().toString());
        if (review.getUpdatedAt() != null)
        {
            response.setUpdatedAt(review.getUpdatedAt().toString());
        }
        return response;
    }

    // Helper method to get all property IDs for debugging
    private List<UUID> getAllPropertyIds()
    {
        return propertyRepository.findAll().stream()
                .map(Property::getId)
                .collect(Collectors.toList());
    }

//    // Get paginated reviews for a property
//    public Page<ReviewDTO.ReviewSummaryDTO> getReviewsByPropertyId(UUID propertyId, Pageable pageable)
//    {
//        Page<Review> reviews = reviewRepository.findByPropertyIdAndIsActiveTrue(propertyId, pageable);
//        return reviews.map(ReviewDTO.ReviewSummaryDTO::new);
//    }
//
//    // Get recent reviews for property preview
//    public List<ReviewDTO.ReviewSummaryDTO> getRecentReviewsByPropertyId(UUID propertyId, int limit) {
//        List<Review> reviews = reviewRepository.findTop3ByPropertyIdAndIsActiveTrueOrderByCreatedAtDesc(propertyId);
//        return reviews.stream()
//                .map(ReviewDTO.ReviewSummaryDTO::new)
//                .collect(Collectors.toList());
//    }

}